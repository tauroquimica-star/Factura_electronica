import { supabase } from '@/integrations/supabase/client';

export type AuditAction = 
  | 'login' 
  | 'logout'
  | 'create_invoice' 
  | 'update_invoice' 
  | 'delete_invoice'
  | 'create_user'
  | 'update_user'
  | 'delete_user'
  | 'update_invoice_status'
  | 'upload_file'
  | 'delete_file';

export type EntityType = 
  | 'invoice' 
  | 'user' 
  | 'file' 
  | 'auth';

interface LogAuditParams {
  action: AuditAction;
  entityType: EntityType;
  entityId?: string;
  details?: Record<string, any>;
}

export const useAuditLog = () => {
  const logAudit = async ({ action, entityType, entityId, details }: LogAuditParams) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) return;

      const { data: profile } = await supabase
        .from('profiles')
        .select('username')
        .eq('id', user.id)
        .single();

      await supabase.from('audit_logs').insert({
        user_id: user.id,
        username: profile?.username || user.email,
        action,
        entity_type: entityType,
        entity_id: entityId,
        details,
        user_agent: navigator.userAgent
      });
    } catch (error) {
      console.error('Error logging audit:', error);
    }
  };

  return { logAudit };
};
