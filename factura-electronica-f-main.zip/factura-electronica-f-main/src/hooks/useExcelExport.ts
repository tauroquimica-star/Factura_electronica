
import { useState } from 'react';
import * as XLSX from 'xlsx';
import { useToast } from '@/hooks/use-toast';

interface Invoice {
  id: string;
  invoiceNumber?: string;
  providerName: string;
  nitProveedor?: string;
  receptionDate: string;
  amount: number;
  cufeCude?: string;
  custodio?: string;
  custodiaContabilidad?: boolean;
  recibidoContabilidad?: boolean;
  recibidoCCR?: boolean;
  fechaCustodiaContabilidad?: string;
  fechaRecibidoContabilidad?: string;
  fechaRecibidoCCR?: string;
  observations?: string;
}

export const useExcelExport = () => {
  const [isExporting, setIsExporting] = useState(false);
  const { toast } = useToast();

  const formatDate = (dateString?: string) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('es-ES');
  };

  const formatDateTime = (dateString?: string) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleString('es-ES', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatBooleanWithDate = (status?: boolean, date?: string) => {
    if (!status) return 'No';
    return date ? `Sí (${formatDate(date)})` : 'Sí';
  };

  const formatBooleanWithDateTime = (status?: boolean, date?: string) => {
    if (!status) return 'No';
    return date ? `Sí (${formatDateTime(date)})` : 'Sí';
  };

  const exportToExcel = async (invoices: Invoice[]) => {
    setIsExporting(true);
    
    try {
      // Preparar los datos para Excel
      const excelData = invoices.map(invoice => ({
        'Número de Factura': invoice.invoiceNumber || invoice.id,
        'Nombre del Proveedor': invoice.providerName,
        'NIT Proveedor': invoice.nitProveedor || 'N/A',
        'Fecha de Recepción': formatDate(invoice.receptionDate),
        'CUFE/CUDE': invoice.cufeCude || 'N/A',
        'Custodio': invoice.custodio || 'N/A',
        'Custodia Contabilidad': formatBooleanWithDate(invoice.custodiaContabilidad, invoice.fechaCustodiaContabilidad),
        'Recibido Contabilidad': formatBooleanWithDateTime(invoice.recibidoContabilidad, invoice.fechaRecibidoContabilidad),
        'Recibido CCR': formatBooleanWithDateTime(invoice.recibidoCCR, invoice.fechaRecibidoCCR),
        'Observaciones': invoice.observations || 'N/A',
        'Valor a Pagar': new Intl.NumberFormat('es-CO', {
          style: 'currency',
          currency: 'COP'
        }).format(invoice.amount)
      }));

      // Crear el libro de trabajo
      const workbook = XLSX.utils.book_new();
      const worksheet = XLSX.utils.json_to_sheet(excelData);

      // Ajustar el ancho de las columnas
      const columnWidths = [
        { wch: 20 }, // Número de Factura
        { wch: 30 }, // Nombre del Proveedor
        { wch: 15 }, // NIT Proveedor
        { wch: 18 }, // Fecha de Recepción
        { wch: 25 }, // CUFE/CUDE
        { wch: 20 }, // Custodio
        { wch: 25 }, // Custodia Contabilidad
        { wch: 25 }, // Recibido Contabilidad
        { wch: 25 }, // Recibido CCR
        { wch: 40 }, // Observaciones
        { wch: 18 }  // Valor a Pagar
      ];
      worksheet['!cols'] = columnWidths;

      // Agregar la hoja al libro
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Facturas');

      // Generar el nombre del archivo con la fecha actual
      const fileName = `facturas_${new Date().toISOString().split('T')[0]}.xlsx`;

      // Descargar el archivo
      XLSX.writeFile(workbook, fileName);

      toast({
        title: "Exportación exitosa",
        description: `Se ha descargado el archivo ${fileName} con ${invoices.length} facturas.`
      });

    } catch (error) {
      console.error('Error exporting to Excel:', error);
      toast({
        title: "Error en la exportación",
        description: "No se pudo generar el archivo Excel. Inténtalo de nuevo.",
        variant: "destructive"
      });
    } finally {
      setIsExporting(false);
    }
  };

  return {
    exportToExcel,
    isExporting
  };
};
