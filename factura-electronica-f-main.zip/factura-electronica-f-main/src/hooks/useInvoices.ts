import { useState, useEffect, useCallback, useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import * as XLSX from 'xlsx';
import { useAuditLog } from '@/hooks/useAuditLog';

interface InvoiceItem {
  description: string;
  quantity: number;
  price: number;
}

interface AttachedFile {
  id: string;
  name: string;
  size: number;
  type: string;
  url?: string;
  file?: File;
  storagePath?: string;
  isUploaded?: boolean;
}

interface Invoice {
  id: string;
  invoiceNumber: string;
  providerName: string;
  nitProveedor?: string;
  amount: number;
  issueDate: string;
  receptionDate: string;
  cufeCude?: string;
  custodio?: string;
  observations?: string;
  custodiaContabilidad?: boolean;
  recibidoContabilidad?: boolean;
  recibidoCCR?: boolean;
  fechaCustodiaContabilidad?: string;
  fechaRecibidoContabilidad?: string;
  fechaRecibidoCCR?: string;
  items: InvoiceItem[];
  attachedFiles?: AttachedFile[];
  date: string;
}

export const useInvoices = () => {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const { logAudit } = useAuditLog();

  // Batch load attachments for better performance
  const loadAttachmentsInBatches = async (invoiceIds: string[]) => {
    const batchSize = 50;
    const batches = [];
    
    for (let i = 0; i < invoiceIds.length; i += batchSize) {
      batches.push(invoiceIds.slice(i, i + batchSize));
    }
    
    const allAttachments = [];
    
    for (const batch of batches) {
      const { data: attachmentsData, error: attachmentsError } = await supabase
        .from('invoice_attachments')
        .select('*')
        .in('invoice_id', batch);

      if (!attachmentsError && attachmentsData) {
        allAttachments.push(...attachmentsData);
      }
    }
    
    return allAttachments;
  };

  const loadInvoices = async () => {
    try {
      console.log('Loading invoices...');
      const { data: invoicesData, error: invoicesError } = await supabase
        .from('invoices')
        .select('*')
        .order('created_at', { ascending: false });

      if (invoicesError) throw invoicesError;

      console.log('Loaded invoices:', invoicesData?.length);

      // Load items in batch
      const invoiceIds = (invoicesData || []).map(inv => inv.id);
      
      const { data: itemsData, error: itemsError } = await supabase
        .from('invoice_items')
        .select('invoice_id, description, quantity, price')
        .in('invoice_id', invoiceIds);

      if (itemsError) {
        console.error('Error loading items:', itemsError);
        throw itemsError;
      }

      // Load attachments in batches
      const attachmentsData = await loadAttachmentsInBatches(invoiceIds);

      // Group items by invoice_id for faster lookup
      const itemsByInvoiceId = (itemsData || []).reduce((acc, item) => {
        if (!acc[item.invoice_id]) acc[item.invoice_id] = [];
        acc[item.invoice_id].push({
          description: item.description,
          quantity: item.quantity,
          price: item.price
        });
        return acc;
      }, {} as Record<string, InvoiceItem[]>);

      // Group attachments by invoice_id for faster lookup
      const attachmentsByInvoiceId = attachmentsData.reduce((acc, attachment) => {
        if (!acc[attachment.invoice_id]) acc[attachment.invoice_id] = [];
        
        const { data: urlData } = supabase.storage
          .from('invoice-attachments')
          .getPublicUrl(attachment.storage_path);

        acc[attachment.invoice_id].push({
          id: attachment.id,
          name: attachment.file_name,
          size: attachment.file_size,
          type: attachment.file_type,
          url: urlData.publicUrl,
          storagePath: attachment.storage_path,
          isUploaded: true
        });
        return acc;
      }, {} as Record<string, AttachedFile[]>);

      // Combine data efficiently
      const invoicesWithDetails = (invoicesData || []).map(invoice => ({
        id: invoice.id,
        invoiceNumber: invoice.invoice_number,
        providerName: invoice.provider_name,
        nitProveedor: invoice.nit_proveedor,
        amount: Number(invoice.amount),
        issueDate: invoice.issue_date,
        receptionDate: invoice.reception_date,
        cufeCude: invoice.cufe_cude,
        custodio: invoice.custodio,
        observations: invoice.observations,
        observationsUser: invoice.observations_user,
        observationsDate: invoice.observations_date,
        custodiaContabilidad: invoice.custodia_contabilidad,
        recibidoContabilidad: invoice.recibido_contabilidad,
        recibidoCCR: invoice.recibido_ccr,
        fechaCustodiaContabilidad: invoice.fecha_custodia_contabilidad,
        fechaRecibidoContabilidad: invoice.fecha_recibido_contabilidad,
        fechaRecibidoCCR: invoice.fecha_recibido_ccr,
        items: itemsByInvoiceId[invoice.id] || [],
        attachedFiles: attachmentsByInvoiceId[invoice.id] || [],
        date: invoice.issue_date,
      }));

      setInvoices(invoicesWithDetails);
    } catch (error) {
      console.error('Error loading invoices:', error);
      toast({
        title: "Error",
        description: "No se pudieron cargar las facturas",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const uploadPendingFiles = async (invoiceId: string, attachedFiles: AttachedFile[]) => {
    const pendingFiles = attachedFiles.filter(file => 
      file.file && !file.isUploaded && file.file instanceof File
    );
    
    console.log('Uploading pending files:', pendingFiles.length);
    
    for (const file of pendingFiles) {
      if (!file.file || !(file.file instanceof File)) {
        console.log('Skipping invalid file:', file.name);
        continue;
      }

      try {
        let fileId = file.id;
        if (!fileId || fileId.length < 8 || !fileId.includes('-')) {
          fileId = crypto.randomUUID();
        }

        const fileExtension = file.name.split('.').pop();
        const fileName = `${fileId}.${fileExtension}`;
        const storagePath = `${invoiceId}/${fileName}`;

        console.log('Uploading file:', file.name, 'to path:', storagePath);

        const { error: uploadError } = await supabase.storage
          .from('invoice-attachments')
          .upload(storagePath, file.file, {
            cacheControl: '3600',
            upsert: false
          });

        if (uploadError) {
          console.error('Upload error:', uploadError);
          throw uploadError;
        }

        console.log('File uploaded successfully, saving to database...');

        const { error: dbError } = await supabase
          .from('invoice_attachments')
          .insert({
            id: fileId,
            invoice_id: invoiceId,
            file_name: file.name,
            file_size: file.size,
            file_type: file.type,
            storage_path: storagePath
          });

        if (dbError) {
          console.error('Database error:', dbError);
          throw dbError;
        }

        console.log('File saved to database successfully');
      } catch (error) {
        console.error('Error uploading file:', file.name, error);
        toast({
          title: "Error",
          description: `No se pudo subir el archivo ${file.name}`,
          variant: "destructive"
        });
      }
    }
  };

  const checkDuplicates = async (invoiceNumber: string, cufeCude?: string, excludeId?: string) => {
    try {
      let invoiceQuery = supabase
        .from('invoices')
        .select('id, invoice_number')
        .eq('invoice_number', invoiceNumber);
      
      if (excludeId) {
        invoiceQuery = invoiceQuery.neq('id', excludeId);
      }

      const { data: existingInvoice, error: invoiceError } = await invoiceQuery;
      
      if (invoiceError) throw invoiceError;

      if (existingInvoice && existingInvoice.length > 0) {
        toast({
          title: "Error",
          description: `Ya existe una factura con el número ${invoiceNumber}`,
          variant: "destructive"
        });
        return false;
      }

      if (cufeCude && cufeCude.trim() !== '') {
        let cufeQuery = supabase
          .from('invoices')
          .select('id, cufe_cude')
          .eq('cufe_cude', cufeCude);
        
        if (excludeId) {
          cufeQuery = cufeQuery.neq('id', excludeId);
        }

        const { data: existingCufe, error: cufeError } = await cufeQuery;
        
        if (cufeError) throw cufeError;

        if (existingCufe && existingCufe.length > 0) {
          toast({
            title: "Error", 
            description: `Ya existe una factura con el CUFE/CUDE ${cufeCude}`,
            variant: "destructive"
          });
          return false;
        }
      }

      return true;
    } catch (error) {
      console.error('Error checking duplicates:', error);
      toast({
        title: "Error",
        description: "Error al validar duplicados",
        variant: "destructive"
      });
      return false;
    }
  };

  const saveInvoice = async (invoiceData: any, isEdit = false, silent = false) => {
    try {
      if (!silent) {
        console.log('Saving invoice:', invoiceData, 'isEdit:', isEdit);
      }
      
      const isDuplicateValid = await checkDuplicates(
        invoiceData.invoiceNumber,
        invoiceData.cufeCude,
        isEdit ? invoiceData.id : undefined
      );

      if (!isDuplicateValid) {
        return false;
      }
      
      const invoiceId = isEdit && invoiceData.id ? invoiceData.id : invoiceData.invoiceNumber || `INV-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      
      const invoiceRecord = {
        id: invoiceId,
        invoice_number: invoiceData.invoiceNumber || invoiceId,
        provider_name: invoiceData.providerName,
        nit_proveedor: invoiceData.nitProveedor,
        amount: Number(invoiceData.amount || 0),
        issue_date: invoiceData.issueDate,
        reception_date: invoiceData.receptionDate,
        cufe_cude: invoiceData.cufeCude || null,
        custodio: invoiceData.custodio || null,
        observations: invoiceData.observations || null,
        observations_user: invoiceData.observationsUser || null,
        observations_date: invoiceData.observationsDate || null,
        custodia_contabilidad: invoiceData.custodiaContabilidad || false,
        recibido_contabilidad: invoiceData.recibidoContabilidad || false,
        recibido_ccr: invoiceData.recibidoCCR || false,
        fecha_custodia_contabilidad: invoiceData.fechaCustodiaContabilidad || null,
        fecha_recibido_contabilidad: invoiceData.fechaRecibidoContabilidad || null,
        fecha_recibido_ccr: invoiceData.fechaRecibidoCCR || null,
      };

      if (!silent) {
        console.log('Invoice record to save:', invoiceRecord);
      }

      if (isEdit) {
        const { error } = await supabase
          .from('invoices')
          .update(invoiceRecord)
          .eq('id', invoiceId);
        if (error) {
          console.error('Error updating invoice:', error);
          throw error;
        }

        const { error: deleteError } = await supabase
          .from('invoice_items')
          .delete()
          .eq('invoice_id', invoiceId);
        if (deleteError) {
          console.error('Error deleting items:', deleteError);
          throw deleteError;
        }
      } else {
        const { error } = await supabase
          .from('invoices')
          .insert([invoiceRecord]);
        if (error) {
          console.error('Error inserting invoice:', error);
          throw error;
        }
      }

      if (invoiceData.items && invoiceData.items.length > 0) {
        const itemsToInsert = invoiceData.items.map((item: InvoiceItem) => ({
          invoice_id: invoiceId,
          description: item.description,
          quantity: Number(item.quantity || 1),
          price: Number(item.price || 0),
        }));

        if (!silent) {
          console.log('Items to insert:', itemsToInsert);
        }

        const { error: itemsError } = await supabase
          .from('invoice_items')
          .insert(itemsToInsert);
        if (itemsError) {
          console.error('Error inserting items:', itemsError);
          throw itemsError;
        }
      }

      if (invoiceData.attachedFiles && invoiceData.attachedFiles.length > 0) {
        console.log('Processing attached files:', invoiceData.attachedFiles.length);
        
        const filesToUpload = invoiceData.attachedFiles.filter((file: AttachedFile) => 
          file.file && 
          file.file instanceof File && 
          !file.isUploaded &&
          !file.url?.includes('supabase')
        );
        
        console.log('Files that need uploading:', filesToUpload.length);
        
        if (filesToUpload.length > 0) {
          console.log('Uploading new files...');
          await uploadPendingFiles(invoiceId, filesToUpload);
        } else {
          console.log('No new files to upload');
        }
      }

      // Optimización: Solo recargar la factura actualizada en lugar de todas
      if (isEdit) {
        const { data: updatedInvoice } = await supabase
          .from('invoices')
          .select('*')
          .eq('id', invoiceId)
          .single();

        if (updatedInvoice) {
          const { data: itemsData } = await supabase
            .from('invoice_items')
            .select('*')
            .eq('invoice_id', invoiceId);

          const { data: attachmentsData } = await supabase
            .from('invoice_attachments')
            .select('*')
            .eq('invoice_id', invoiceId);

          const attachedFiles = (attachmentsData || []).map(attachment => {
            const { data: urlData } = supabase.storage
              .from('invoice-attachments')
              .getPublicUrl(attachment.storage_path);

            return {
              id: attachment.id,
              name: attachment.file_name,
              size: attachment.file_size,
              type: attachment.file_type,
              url: urlData.publicUrl,
              storagePath: attachment.storage_path,
              isUploaded: true
            };
          });

          const invoiceWithDetails = {
            id: updatedInvoice.id,
            invoiceNumber: updatedInvoice.invoice_number,
            providerName: updatedInvoice.provider_name,
            nitProveedor: updatedInvoice.nit_proveedor,
            amount: Number(updatedInvoice.amount),
            issueDate: updatedInvoice.issue_date,
            receptionDate: updatedInvoice.reception_date,
            cufeCude: updatedInvoice.cufe_cude,
            custodio: updatedInvoice.custodio,
            observations: updatedInvoice.observations,
            observationsUser: updatedInvoice.observations_user,
            observationsDate: updatedInvoice.observations_date,
            custodiaContabilidad: updatedInvoice.custodia_contabilidad,
            recibidoContabilidad: updatedInvoice.recibido_contabilidad,
            recibidoCCR: updatedInvoice.recibido_ccr,
            fechaCustodiaContabilidad: updatedInvoice.fecha_custodia_contabilidad,
            fechaRecibidoContabilidad: updatedInvoice.fecha_recibido_contabilidad,
            fechaRecibidoCCR: updatedInvoice.fecha_recibido_ccr,
            items: (itemsData || []).map(item => ({
              description: item.description,
              quantity: item.quantity,
              price: item.price
            })),
            attachedFiles,
            date: updatedInvoice.issue_date,
          };

          setInvoices(prev => prev.map(inv => 
            inv.id === invoiceId ? invoiceWithDetails : inv
          ));
        }
      } else {
        await loadInvoices();
      }

      if (!silent) {
        toast({
          title: isEdit ? "Factura actualizada" : "Factura creada",
          description: isEdit ? "Los cambios se han guardado exitosamente" : "La factura ha sido creada exitosamente"
        });
        
        await logAudit({
          action: isEdit ? 'update_invoice' : 'create_invoice',
          entityType: 'invoice',
          entityId: invoiceId,
          details: {
            invoiceNumber: invoiceData.invoiceNumber,
            providerName: invoiceData.providerName,
            amount: invoiceData.amount
          }
        });
      }

      return true;
    } catch (error) {
      if (!silent) {
        console.error('Error saving invoice:', error);
        toast({
          title: "Error",
          description: isEdit ? "No se pudo actualizar la factura" : "No se pudo crear la factura",
          variant: "destructive"
        });
      }
      return false;
    }
  };

  const saveInvoicesFromExcel = async (file: File) => {
    setLoading(true);
    try {
      const data = await file.arrayBuffer();
      const workbook = XLSX.read(data);
      const worksheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[worksheetName];
      const rows: any[][] = XLSX.utils.sheet_to_json(worksheet, {
        header: 1,
        cellDates: true,
      } as any);

      if (rows.length < 2) {
        toast({
          title: "Archivo inválido",
          description:
            "El archivo Excel debe contener una fila de cabecera y al menos una fila de datos.",
          variant: "destructive",
        });
        setLoading(false);
        return;
      }

      const headers = rows[0].map((h) => String(h).trim().toLowerCase());
      const dataRows = rows.slice(1);

      const headerMap: { [key: string]: string } = {
        'numero factura': 'invoiceNumber',
        'número de factura': 'invoiceNumber',
        'nombre proveedor': 'providerName',
        'nombre del proveedor': 'providerName',
        'nit proveedor': 'nitProveedor',
        valor: 'amount',
        'valor a pagar': 'amount',
        'fecha emision': 'issueDate',
        'fecha de emision': 'issueDate',
        'fecha de emisión': 'issueDate',
        'fecha recepcion': 'receptionDate',
        'fecha de recepcion': 'receptionDate',
        'fecha de recepción': 'receptionDate',
        'cufe/cude': 'cufeCude',
        custodio: 'custodio',
        observaciones: 'observations',
      };

      const json = dataRows.map((rowValues) => {
        const obj: any = {};
        headers.forEach((header, i) => {
          const key = headerMap[header];
          if (key) {
            obj[key] = rowValues[i];
          }
        });
        return obj;
      });

      if (json.length === 0) {
        toast({
          title: "Archivo vacío",
          description: "El archivo Excel no contiene datos.",
          variant: "destructive",
        });
        setLoading(false);
        return;
      }

      toast({
        title: "Procesando archivo...",
        description: `Se encontraron ${json.length} facturas para crear. Esto puede tardar un momento.`,
      });

      let createdCount = 0;
      let errorCount = 0;
      const errorMessages: string[] = [];

      const parseAmount = (value: any): number => {
        if (typeof value === "number") return value;
        if (typeof value === "string") {
          const cleanedValue = value
            .replace(/[$\s]/g, "")
            .replace(/\./g, "")
            .replace(/,/g, ".");
          const number = parseFloat(cleanedValue);
          return isNaN(number) ? 0 : number;
        }
        return 0;
      };

      const formatDate = (date: any): string => {
        if (date instanceof Date && !isNaN(date.getTime())) {
          const year = date.getUTCFullYear();
          const month = String(date.getUTCMonth() + 1).padStart(2, "0");
          const day = String(date.getUTCDate()).padStart(2, "0");
          return `${year}-${month}-${day}`;
        }
        
        if (typeof date === 'number') {
          const d = XLSX.SSF.parse_date_code(date);
          if (d) {
            const isoDate = `${d.y}-${String(d.m).padStart(2, '0')}-${String(d.d).padStart(2, '0')}`;
             if (!isNaN(new Date(isoDate).getTime())) {
              return isoDate;
            }
          }
        }

        if (typeof date === "string") {
          const parts = date.split("/");
          if (parts.length === 3) {
            const [day, month, year] = parts;
            const isoDate = `${year}-${month.padStart(
              2,
              "0"
            )}-${day.padStart(2, "0")}`;
            if (!isNaN(new Date(isoDate).getTime())) {
              return isoDate;
            }
          }
        }
        return "";
      };

      for (const row of json) {
        const invoiceData = {
          invoiceNumber: row.invoiceNumber,
          providerName: row.providerName,
          nitProveedor: row.nitProveedor,
          amount: parseAmount(row.amount),
          issueDate: formatDate(row.issueDate),
          receptionDate: formatDate(row.receptionDate),
          cufeCude: row.cufeCude,
          custodio: row.custodio,
          observations: row.observations,
          items: [],
          attachedFiles: [],
        };

        if (
          !invoiceData.invoiceNumber ||
          !invoiceData.providerName ||
          !invoiceData.amount ||
          !invoiceData.issueDate ||
          !invoiceData.receptionDate
        ) {
          errorCount++;
          errorMessages.push(
            `Fila inválida (faltan datos obligatorios: Número Factura, Proveedor, Valor, Fechas): ${JSON.stringify(
              row
            )}`
          );
          continue;
        }
        
        const success = await saveInvoice(invoiceData, false, true);
        if (success) {
          createdCount++;
        } else {
          errorCount++;
          errorMessages.push(
            `Error al guardar factura ${invoiceData.invoiceNumber}. Posible duplicado.`
          );
        }
      }

      await loadInvoices();

      toast({
        title: "Carga masiva completada",
        description: `${createdCount} facturas creadas. ${errorCount} facturas con errores.`,
      });

      if (errorCount > 0) {
        console.error("Errores durante la carga masiva:", errorMessages);
      }
    } catch (error) {
      console.error("Error processing Excel file:", error);
      toast({
        title: "Error",
        description:
          "No se pudo procesar el archivo Excel. Verifique el formato.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const deleteInvoice = async (invoiceId: string) => {
    try {
      const { data: attachments } = await supabase
        .from('invoice_attachments')
        .select('storage_path')
        .eq('invoice_id', invoiceId);

      if (attachments && attachments.length > 0) {
        const storagePaths = attachments.map(att => att.storage_path);
        await supabase.storage
          .from('invoice-attachments')
          .remove(storagePaths);
      }

      const { error } = await supabase
        .from('invoices')
        .delete()
        .eq('id', invoiceId);

      if (error) throw error;

      await loadInvoices();

      toast({
        title: "Factura eliminada",
        description: "La factura ha sido eliminada exitosamente"
      });
      
      await logAudit({
        action: 'delete_invoice',
        entityType: 'invoice',
        entityId: invoiceId,
        details: { invoiceId }
      });

      return true;
    } catch (error) {
      console.error('Error deleting invoice:', error);
      toast({
        title: "Error",
        description: "No se pudo eliminar la factura",
        variant: "destructive"
      });
      return false;
    }
  };

  const bulkDeleteInvoices = async (invoiceIds: string[]) => {
    try {
      const { data: attachments } = await supabase
        .from('invoice_attachments')
        .select('storage_path')
        .in('invoice_id', invoiceIds);

      if (attachments && attachments.length > 0) {
        const storagePaths = attachments.map(att => att.storage_path);
        await supabase.storage
          .from('invoice-attachments')
          .remove(storagePaths);
      }

      const { error } = await supabase
        .from('invoices')
        .delete()
        .in('id', invoiceIds);

      if (error) throw error;

      await loadInvoices();

      toast({
        title: "Facturas eliminadas",
        description: `Se han eliminado ${invoiceIds.length} facturas exitosamente`
      });

      return true;
    } catch (error) {
      console.error('Error deleting invoices:', error);
      toast({
        title: "Error",
        description: "No se pudieron eliminar las facturas",
        variant: "destructive"
      });
      return false;
    }
  };

  const updateInvoiceStatus = async (invoiceId: string, field: string, value: boolean) => {
    try {
      const fieldMapping: { [key: string]: string } = {
        'custodiaContabilidad': 'custodia_contabilidad',
        'recibidoContabilidad': 'recibido_contabilidad',
        'recibidoCCR': 'recibido_ccr'
      };

      const dbField = fieldMapping[field] || field;
      
      const updateData: any = {
        [dbField]: value
      };

      if (value) {
        const timestampField = `fecha_${dbField}`;
        updateData[timestampField] = new Date().toISOString();
      } else {
        const timestampField = `fecha_${dbField}`;
        updateData[timestampField] = null;
      }

      console.log('Updating invoice status:', { invoiceId, updateData });

      const { error } = await supabase
        .from('invoices')
        .update(updateData)
        .eq('id', invoiceId);

      if (error) throw error;
      
      await logAudit({
        action: 'update_invoice_status',
        entityType: 'invoice',
        entityId: invoiceId,
        details: { field, value, dbField }
      });

      setInvoices(prev => prev.map(invoice => {
        if (invoice.id === invoiceId) {
          const updatedInvoice = { ...invoice };
          
          if (field === 'custodiaContabilidad') {
            updatedInvoice.custodiaContabilidad = value;
            updatedInvoice.fechaCustodiaContabilidad = value ? new Date().toISOString() : undefined;
          } else if (field === 'recibidoContabilidad') {
            updatedInvoice.recibidoContabilidad = value;
            updatedInvoice.fechaRecibidoContabilidad = value ? new Date().toISOString() : undefined;
          } else if (field === 'recibidoCCR') {
            updatedInvoice.recibidoCCR = value;
            updatedInvoice.fechaRecibidoCCR = value ? new Date().toISOString() : undefined;
          }
          
          return updatedInvoice;
        }
        return invoice;
      }));

      toast({
        title: "Estado actualizado",
        description: `El estado de procesamiento ha sido ${value ? 'activado' : 'desactivado'} exitosamente`
      });

      return true;
    } catch (error) {
      console.error('Error updating invoice status:', error);
      toast({
        title: "Error",
        description: "No se pudo actualizar el estado de procesamiento",
        variant: "destructive"
      });
      return false;
    }
  };

  useEffect(() => {
    loadInvoices();
  }, []);

  return {
    invoices,
    loading,
    saveInvoice,
    deleteInvoice,
    bulkDeleteInvoices,
    updateInvoiceStatus,
    refreshInvoices: loadInvoices,
    saveInvoicesFromExcel
  };
};
