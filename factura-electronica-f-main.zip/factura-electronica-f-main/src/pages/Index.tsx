
import { useState, memo, useMemo, useCallback, lazy, Suspense, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Calculator, FileCheck, LogOut, User, Plus, Users, ScrollText } from "lucide-react";
import InvoiceHeader from "@/components/invoice/InvoiceHeader";
import InvoiceFormCard from "@/components/invoice/InvoiceFormCard";
import InvoiceListCard from "@/components/invoice/InvoiceListCard";
import { useInvoices } from "@/hooks/useInvoices";
import InvoiceExcelUpload from "@/components/invoice/InvoiceExcelUpload";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "@/hooks/use-toast";
import { AuditLogs } from "@/components/AuditLogs";
import { useAuditLog } from "@/hooks/useAuditLog";

// Lazy load heavy components
const InvoiceDetail = lazy(() => import("@/components/InvoiceDetail"));

interface IndexProps {
  onLogout: () => void;
}

const Index = ({ onLogout }: IndexProps) => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("facturas");
  const [selectedInvoice, setSelectedInvoice] = useState<string | null>(null);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [editingInvoice, setEditingInvoice] = useState<any>(null);
  const [showAuditLogs, setShowAuditLogs] = useState(false);

  const { invoices, loading, saveInvoice, deleteInvoice, bulkDeleteInvoices, updateInvoiceStatus, saveInvoicesFromExcel } = useInvoices();
  const { logAudit } = useAuditLog();

  const [currentUser, setCurrentUser] = useState<string>(localStorage.getItem("currentUser") || "Usuario");

  useEffect(() => {
    const storedUser = localStorage.getItem("currentUser");
    if (storedUser) {
      setCurrentUser(storedUser);
    }
  }, []);

  const filteredInvoices = useMemo(() => 
    invoices.filter(invoice => 
      !invoice.recibidoCCR && !invoice.custodiaContabilidad
    ), [invoices]
  );

  const handleCreateInvoice = useCallback(async (newInvoice: any) => {
    const success = await saveInvoice(newInvoice, !!editingInvoice);
    if (success) {
      setShowCreateForm(false);
      setEditingInvoice(null);
    }
  }, [saveInvoice, editingInvoice]);

  const handleViewInvoice = useCallback((invoiceId: string) => {
    setSelectedInvoice(invoiceId);
    setActiveTab("detail");
  }, []);

  const handleEditInvoice = useCallback((invoiceId: string) => {
    const invoice = invoices.find(inv => inv.id === invoiceId);
    if (invoice) {
      setEditingInvoice(invoice);
      setShowCreateForm(true);
    }
  }, [invoices]);

  const handleDeleteInvoice = useCallback(async (invoiceId: string) => {
    await deleteInvoice(invoiceId);
  }, [deleteInvoice]);

  const handleBulkDeleteInvoices = useCallback(async (invoiceIds: string[]) => {
    await bulkDeleteInvoices(invoiceIds);
  }, [bulkDeleteInvoices]);

  const handleCancelForm = useCallback(() => {
    setShowCreateForm(false);
    setEditingInvoice(null);
  }, []);

  const handleExcelUpload = useCallback(async (file: File) => {
    if (saveInvoicesFromExcel) {
      await saveInvoicesFromExcel(file);
    }
  }, [saveInvoicesFromExcel]);

  if (showAuditLogs) {
    return <AuditLogs onBack={() => setShowAuditLogs(false)} />;
  }

  if (activeTab === "detail" && selectedInvoice) {
    const invoice = invoices.find(inv => inv.id === selectedInvoice);
    if (invoice) {
      return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
          <Suspense fallback={
            <div className="flex items-center justify-center min-h-screen">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
            </div>
          }>
            <InvoiceDetail 
              invoice={invoice} 
              onBack={() => {
                setActiveTab("facturas");
                setSelectedInvoice(null);
              }}
              onUpdateInvoiceStatus={updateInvoiceStatus}
            />
          </Suspense>
        </div>
      );
    }
  }

  if (loading && !showCreateForm) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-slate-600">Cargando facturas...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="container mx-auto px-2 sm:px-4 py-4 sm:py-8">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4">
          <InvoiceHeader />
          <div className="flex items-center gap-2 sm:gap-4 w-full sm:w-auto">
            <div className="flex items-center gap-2 bg-white/80 backdrop-blur-sm px-2 sm:px-3 py-2 rounded-lg border flex-1 sm:flex-initial">
              <User className="h-4 w-4 text-blue-600" />
              <span className="text-xs sm:text-sm font-medium text-slate-700 truncate">{currentUser}</span>
            </div>
            <Button
              onClick={async () => {
                await logAudit({
                  action: 'logout',
                  entityType: 'auth',
                  details: { user: currentUser }
                });
                onLogout();
              }}
              variant="outline"
              size="sm"
              className="border-red-200 text-red-600 hover:bg-red-50"
            >
              <LogOut className="h-4 w-4 sm:mr-2" />
              <span className="hidden sm:inline">Cerrar Sesión</span>
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:flex sm:justify-center gap-2 sm:gap-4 mb-6">
          <Button
            onClick={() => navigate("/ccr")}
            size="sm"
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            <FileCheck className="h-4 w-4 sm:mr-2" />
            <span className="hidden sm:inline">CCR</span>
          </Button>
          <Button
            onClick={() => navigate("/contabilidad")}
            size="sm"
            className="bg-green-600 hover:bg-green-700 text-white"
          >
            <Calculator className="h-4 w-4 sm:mr-2" />
            <span className="hidden sm:inline">Contabilidad</span>
          </Button>
          <AdminUsersLink />
          <AdminAuditLogsLink onViewLogs={() => setShowAuditLogs(true)} />
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full max-w-md grid-cols-1 bg-white/80 backdrop-blur-sm">
            <TabsTrigger value="facturas" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              Facturas Tauroquímica
            </TabsTrigger>
          </TabsList>

          <TabsContent value="facturas" className="space-y-6">
            {showCreateForm ? (
              <InvoiceFormCard
                editingInvoice={editingInvoice}
                onSubmit={handleCreateInvoice}
                onCancel={handleCancelForm}
              />
            ) : (
              <>
                <div className="flex flex-col sm:flex-row justify-end gap-2">
                  <InvoiceExcelUpload onFileUpload={handleExcelUpload} isLoading={loading} />
                  <Button 
                    onClick={() => {
                      if (user?.email === 'ccr@tauroquimica.co' || user?.email === 'contabilidad@tauroquimica.co') {
                        toast({
                          title: 'Acceso restringido',
                          description: 'No tiene autorización para realizar esta acción',
                          variant: 'destructive',
                        });
                        return;
                      }
                      setShowCreateForm(true);
                    }}
                    className="w-full sm:w-auto"
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Nueva Factura
                  </Button>
                </div>
                <InvoiceListCard
                  invoices={invoices}
                  filteredInvoices={filteredInvoices}
                  invoiceStatusFilter="all"
                  onStatusFilterChange={() => {}}
                  onCreateInvoice={() => {}}
                  onViewInvoice={handleEditInvoice}
                  onDeleteInvoice={handleDeleteInvoice}
                  onBulkDeleteInvoices={handleBulkDeleteInvoices}
                  onUpdateInvoiceStatus={updateInvoiceStatus}
                  hideCreateButton={true}
                />
              </>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

const AdminUsersLink = () => {
  const navigate = useNavigate();
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    const checkRole = async () => {
      try {
        const { data } = await supabase.rpc('get_current_user_role');
        setIsAdmin(data === 'Admin');
      } catch {
        setIsAdmin(false);
      }
    };
    checkRole();
  }, []);

  if (!isAdmin) return null;
  return (
    <Button onClick={() => navigate('/usuarios')} size="sm" className="bg-purple-600 hover:bg-purple-700 text-white">
      <Users className="h-4 w-4 sm:mr-2" />
      <span className="hidden sm:inline">Usuarios</span>
    </Button>
  );
};

const AdminAuditLogsLink = ({ onViewLogs }: { onViewLogs: () => void }) => {
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    const checkRole = async () => {
      try {
        const { data } = await supabase.rpc('get_current_user_role');
        setIsAdmin(data === 'Admin');
      } catch {
        setIsAdmin(false);
      }
    };
    checkRole();
  }, []);

  if (!isAdmin) return null;
  return (
    <Button onClick={onViewLogs} size="sm" className="bg-orange-600 hover:bg-orange-700 text-white">
      <ScrollText className="h-4 w-4 sm:mr-2" />
      <span className="hidden sm:inline">Auditoría</span>
    </Button>
  );
};

export default memo(Index);
