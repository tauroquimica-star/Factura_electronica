import { useState } from "react";
import { Button } from "@/components/ui/button";
import { LogOut, ArrowLeft, User } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import InvoiceHeader from "@/components/invoice/InvoiceHeader";
import InvoiceFormCard from "@/components/invoice/InvoiceFormCard";
import InvoiceListCard from "@/components/invoice/InvoiceListCard";
import { useInvoices } from "@/hooks/useInvoices";

interface ContabilidadProps {
  onLogout: () => void;
}

const Contabilidad = ({ onLogout }: ContabilidadProps) => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("facturas");
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [editingInvoice, setEditingInvoice] = useState<any>(null);

  const { invoices, loading, saveInvoice, deleteInvoice, bulkDeleteInvoices, updateInvoiceStatus } = useInvoices();

  // Get current user from localStorage
  const currentUser = localStorage.getItem("currentUser") || "Usuario";

  // Filter invoices that are in custody of accounting
  const filteredInvoices = invoices.filter(invoice => 
    invoice.custodiaContabilidad
  );

  const handleCreateInvoice = async (newInvoice: any) => {
    const success = await saveInvoice(newInvoice, !!editingInvoice);
    if (success) {
      setShowCreateForm(false);
      setEditingInvoice(null);
    }
  };

  const handleEditInvoice = (invoiceId: string) => {
    const invoice = invoices.find(inv => inv.id === invoiceId);
    if (invoice) {
      setEditingInvoice(invoice);
      setShowCreateForm(true);
    }
  };

  const handleDeleteInvoice = async (invoiceId: string) => {
    await deleteInvoice(invoiceId);
  };

  const handleBulkDeleteInvoices = async (invoiceIds: string[]) => {
    await bulkDeleteInvoices(invoiceIds);
  };

  const handleCancelForm = () => {
    setShowCreateForm(false);
    setEditingInvoice(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto"></div>
          <p className="mt-4 text-slate-600">Cargando facturas...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center gap-4">
            <Button
              onClick={() => navigate("/")}
              variant="outline"
              className="border-gray-200"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Volver
            </Button>
            <InvoiceHeader />
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 bg-white/80 backdrop-blur-sm px-3 py-2 rounded-lg border">
              <User className="h-4 w-4 text-green-600" />
              <span className="text-sm font-medium text-slate-700">{currentUser}</span>
            </div>
            <Button
              onClick={onLogout}
              variant="outline"
              className="border-red-200 text-red-600 hover:bg-red-50"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Cerrar Sesión
            </Button>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full max-w-md grid-cols-1 bg-white/80 backdrop-blur-sm">
            <TabsTrigger value="facturas" className="data-[state=active]:bg-green-600 data-[state=active]:text-white">
              Contabilidad
            </TabsTrigger>
          </TabsList>

          <TabsContent value="facturas" className="space-y-6">
            {showCreateForm ? (
              <InvoiceFormCard
                editingInvoice={editingInvoice}
                onSubmit={handleCreateInvoice}
                onCancel={handleCancelForm}
              />
            ) : (
              <InvoiceListCard
                invoices={invoices}
                filteredInvoices={filteredInvoices}
                invoiceStatusFilter="all"
                onStatusFilterChange={() => {}}
                onCreateInvoice={() => {}}
                onViewInvoice={handleEditInvoice}
                onDeleteInvoice={handleDeleteInvoice}
                onBulkDeleteInvoices={handleBulkDeleteInvoices}
                onUpdateInvoiceStatus={updateInvoiceStatus}
                hideCreateButton={true}
                showTotal={false}
                showCCR={false}
                showContabilidad={true}
              />
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Contabilidad;
