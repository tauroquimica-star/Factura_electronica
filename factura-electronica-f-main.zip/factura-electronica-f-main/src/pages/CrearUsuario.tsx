import { useNavigate } from "react-router-dom";
import UserRegistration from "@/components/UserRegistration";

const CrearUsuario = () => {
  const navigate = useNavigate();
  return (
    <UserRegistration 
      onBack={() => navigate('/usuarios')}
      onUserCreated={() => navigate('/usuarios')}
    />
  );
};

export default CrearUsuario;
