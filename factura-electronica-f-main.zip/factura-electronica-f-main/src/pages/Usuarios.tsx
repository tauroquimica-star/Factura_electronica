import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import UserManagement from "@/components/UserManagement";
import { AuditLogs } from "@/components/AuditLogs";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { ShieldAlert, Users } from "lucide-react";

const Usuarios = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [role, setRole] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [showAuditLogs, setShowAuditLogs] = useState(false);

  useEffect(() => {
    const fetchRole = async () => {
      try {
        const { data, error } = await supabase.rpc('get_current_user_role');
        if (error) throw error;
        console.log("Current user role:", data);
        setRole((data as string) ?? 'user');
      } catch (err: any) {
        toast({
          title: "Error al obtener rol",
          description: err.message || 'No fue posible verificar permisos',
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };
    fetchRole();
  }, [toast]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-slate-600">Cargando permisos...</p>
        </div>
      </div>
    );
  }

  if (role !== 'Admin') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-0 shadow-xl bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center space-y-4">
            <div className="mx-auto w-16 h-16 bg-red-600 rounded-full flex items-center justify-center">
              <ShieldAlert className="h-8 w-8 text-white" />
            </div>
            <CardTitle className="text-2xl text-slate-900">Acceso restringido</CardTitle>
            <CardDescription>Solo administradores pueden gestionar usuarios.</CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center pb-6">
            <Button variant="outline" onClick={() => navigate('/')}>Volver al inicio</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (showAuditLogs) {
    return <AuditLogs onBack={() => setShowAuditLogs(false)} />;
  }

  return (
    <UserManagement 
      onBack={() => navigate('/')} 
      onCreateUser={() => navigate('/usuarios/crear')}
      onViewLogs={() => setShowAuditLogs(true)}
    />
  );
};

export default Usuarios;
