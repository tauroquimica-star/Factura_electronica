
import StatusCheckboxSection from "./invoice/StatusCheckboxSection";
import InvoiceDetailHeader from "./invoice/InvoiceDetailHeader";
import InvoiceDetailCard from "./invoice/InvoiceDetailCard";

interface AttachedFile {
  id: string;
  name: string;
  size: number;
  type: string;
  url?: string;
  storagePath?: string;
  isUploaded?: boolean;
}

interface Invoice {
  id: string;
  providerName: string;
  amount: number;
  issueDate: string;
  receptionDate: string;
  items: Array<{
    description: string;
    quantity: number;
    price: number;
  }>;
  cufeCude?: string;
  custodio?: string;
  custodiaContabilidad?: boolean;
  recibidoContabilidad?: boolean;
  recibidoCCR?: boolean;
  fechaCustodiaContabilidad?: string;
  fechaRecibidoContabilidad?: string;
  fechaRecibidoCCR?: string;
  attachedFiles?: AttachedFile[];
}

interface InvoiceDetailProps {
  invoice: Invoice;
  onBack: () => void;
  onUpdateInvoiceStatus?: (invoiceId: string, field: string, value: boolean) => void;
}

const InvoiceDetail = ({ invoice, onBack, onUpdateInvoiceStatus }: InvoiceDetailProps) => {
  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <InvoiceDetailHeader onBack={onBack} />

      {/* Status Checkboxes Section */}
      <div className="mb-6">
        <StatusCheckboxSection
          custodiaContabilidad={invoice.custodiaContabilidad || false}
          recibidoContabilidad={invoice.recibidoContabilidad || false}
          recibidoCCR={invoice.recibidoCCR || false}
          fechaCustodiaContabilidad={invoice.fechaCustodiaContabilidad || ""}
          fechaRecibidoContabilidad={invoice.fechaRecibidoContabilidad || ""}
          fechaRecibidoCCR={invoice.fechaRecibidoCCR || ""}
          onCustodiaContabilidadChange={(checked) => {
            console.log(`InvoiceDetail: custodiaContabilidad changing to ${checked} for invoice ${invoice.id}`);
            onUpdateInvoiceStatus?.(invoice.id, 'custodiaContabilidad', checked);
          }}
          onRecibidoContabilidadChange={(checked) => {
            console.log(`InvoiceDetail: recibidoContabilidad changing to ${checked} for invoice ${invoice.id}`);
            onUpdateInvoiceStatus?.(invoice.id, 'recibidoContabilidad', checked);
          }}
          onRecibidoCCRChange={(checked) => {
            console.log(`InvoiceDetail: recibidoCCR changing to ${checked} for invoice ${invoice.id}`);
            onUpdateInvoiceStatus?.(invoice.id, 'recibidoCCR', checked);
          }}
        />
      </div>

      <InvoiceDetailCard invoice={invoice} />
    </div>
  );
};

export default InvoiceDetail;
