import { useState, useEffect } from 'react';
import * as XLSX from 'xlsx';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Filter, Download, Trash2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface AuditLog {
  id: string;
  username: string;
  action: string;
  entity_type: string;
  entity_id: string | null;
  details: any;
  created_at: string;
  ip_address: string | null;
}

interface AuditLogsProps {
  onBack: () => void;
}

export const AuditLogs = ({ onBack }: AuditLogsProps) => {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterAction, setFilterAction] = useState<string>('all');
  const [filterUser, setFilterUser] = useState<string>('all');
  const [users, setUsers] = useState<string[]>([]);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [logToDelete, setLogToDelete] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    loadLogs();
  }, [filterAction, filterUser]);

  const loadLogs = async () => {
    setLoading(true);
    try {
      let query = supabase
        .from('audit_logs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);

      if (filterAction !== 'all') {
        query = query.eq('action', filterAction);
      }

      if (filterUser !== 'all') {
        query = query.eq('username', filterUser);
      }

      const { data, error } = await query;

      if (error) throw error;

      setLogs(data || []);

      // Extract unique usernames
      const uniqueUsers = [...new Set((data || []).map(log => log.username).filter(Boolean))];
      setUsers(uniqueUsers as string[]);
    } catch (error) {
      console.error('Error loading audit logs:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('es-ES', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const getActionBadgeVariant = (action: string) => {
    if (action.includes('delete')) return 'destructive';
    if (action.includes('create')) return 'default';
    if (action.includes('update')) return 'secondary';
    return 'outline';
  };

  const translateAction = (action: string) => {
    const translations: Record<string, string> = {
      'login': 'Inicio de sesión',
      'logout': 'Cierre de sesión',
      'create_invoice': 'Crear factura',
      'update_invoice': 'Actualizar factura',
      'delete_invoice': 'Eliminar factura',
      'create_user': 'Crear usuario',
      'update_user': 'Actualizar usuario',
      'delete_user': 'Eliminar usuario',
      'update_invoice_status': 'Actualizar estado factura',
      'upload_file': 'Subir archivo',
      'delete_file': 'Eliminar archivo'
    };
    return translations[action] || action;
  };

  const downloadReport = () => {
    const data = logs.map(log => ({
      'Fecha y Hora': formatDate(log.created_at),
      'Usuario': log.username,
      'Acción': translateAction(log.action),
      'Tipo': log.entity_type,
      'ID Entidad': log.entity_id || '-',
      'Detalles': log.details ? JSON.stringify(log.details) : '-',
      'IP': log.ip_address || '-'
    }));

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Auditoría');

    const columnWidths = [
      { wch: 20 }, // Fecha y Hora
      { wch: 25 }, // Usuario
      { wch: 25 }, // Acción
      { wch: 15 }, // Tipo
      { wch: 20 }, // ID Entidad
      { wch: 40 }, // Detalles
      { wch: 15 }  // IP
    ];
    worksheet['!cols'] = columnWidths;

    const fileName = `auditoria_${new Date().toISOString().split('T')[0]}.xlsx`;
    XLSX.writeFile(workbook, fileName);
  };

  const handleDeleteLog = async () => {
    if (!logToDelete) return;

    try {
      const { error } = await supabase
        .from('audit_logs')
        .delete()
        .eq('id', logToDelete);

      if (error) throw error;

      toast({
        title: "Registro eliminado",
        description: "El registro de auditoría ha sido eliminado exitosamente",
      });

      await loadLogs();
    } catch (error) {
      console.error('Error deleting audit log:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "No se pudo eliminar el registro de auditoría",
      });
    } finally {
      setDeleteDialogOpen(false);
      setLogToDelete(null);
    }
  };

  const handleClearAllLogs = async () => {
    try {
      const { error } = await supabase
        .from('audit_logs')
        .delete()
        .neq('id', '00000000-0000-0000-0000-000000000000'); // Delete all records

      if (error) throw error;

      toast({
        title: "Registros eliminados",
        description: "Todos los registros de auditoría han sido eliminados",
      });

      await loadLogs();
    } catch (error) {
      console.error('Error clearing audit logs:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "No se pudieron eliminar los registros de auditoría",
      });
    } finally {
      setDeleteDialogOpen(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <CardTitle>Registro de Auditoría</CardTitle>
          </div>
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              onClick={downloadReport}
              disabled={logs.length === 0}
            >
              <Download className="h-4 w-4 mr-2" />
              Descargar Informe
            </Button>
            <Button 
              variant="destructive" 
              onClick={() => {
                setLogToDelete('all');
                setDeleteDialogOpen(true);
              }}
              disabled={logs.length === 0}
            >
              <Trash2 className="h-4 w-4 mr-2" />
              Borrar Todos
            </Button>
            <Select value={filterUser} onValueChange={setFilterUser}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filtrar por usuario" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los usuarios</SelectItem>
                {users.map(user => (
                  <SelectItem key={user} value={user}>{user}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterAction} onValueChange={setFilterAction}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filtrar por acción" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas las acciones</SelectItem>
                <SelectItem value="login">Inicio de sesión</SelectItem>
                <SelectItem value="create_invoice">Crear factura</SelectItem>
                <SelectItem value="update_invoice">Actualizar factura</SelectItem>
                <SelectItem value="delete_invoice">Eliminar factura</SelectItem>
                <SelectItem value="create_user">Crear usuario</SelectItem>
                <SelectItem value="update_user">Actualizar usuario</SelectItem>
                <SelectItem value="delete_user">Eliminar usuario</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="text-center py-8">Cargando logs...</div>
        ) : (
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Fecha y Hora</TableHead>
                  <TableHead>Usuario</TableHead>
                  <TableHead>Acción</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead>ID Entidad</TableHead>
                  <TableHead>Detalles</TableHead>
                  <TableHead className="text-right">Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {logs.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center text-muted-foreground">
                      No hay registros de auditoría
                    </TableCell>
                  </TableRow>
                ) : (
                  logs.map((log) => (
                    <TableRow key={log.id}>
                      <TableCell className="font-mono text-sm">
                        {formatDate(log.created_at)}
                      </TableCell>
                      <TableCell className="font-medium">{log.username}</TableCell>
                      <TableCell>
                        <Badge variant={getActionBadgeVariant(log.action)}>
                          {translateAction(log.action)}
                        </Badge>
                      </TableCell>
                      <TableCell className="capitalize">{log.entity_type}</TableCell>
                      <TableCell className="font-mono text-xs">
                        {log.entity_id ? log.entity_id.substring(0, 8) + '...' : '-'}
                      </TableCell>
                      <TableCell className="max-w-xs truncate text-sm text-muted-foreground">
                        {log.details ? JSON.stringify(log.details) : '-'}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => {
                            setLogToDelete(log.id);
                            setDeleteDialogOpen(true);
                          }}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {logToDelete === 'all' ? '¿Borrar todos los registros?' : '¿Borrar este registro?'}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {logToDelete === 'all' 
                ? 'Esta acción eliminará todos los registros de auditoría. Esta acción no se puede deshacer.'
                : 'Esta acción eliminará este registro de auditoría de forma permanente.'
              }
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={logToDelete === 'all' ? handleClearAllLogs : handleDeleteLog}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  );
};
