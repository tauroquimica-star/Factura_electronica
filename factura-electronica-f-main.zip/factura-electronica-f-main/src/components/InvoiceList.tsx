import { useState, memo, useMemo, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Edit, Search, Trash2, Trash, Paperclip } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import DeleteInvoiceDialog from "./DeleteInvoiceDialog";
import PasswordConfirmDialog from "./PasswordConfirmDialog";
import BulkDeleteDialog from "./BulkDeleteDialog";

interface AttachedFile {
  id: string;
  name: string;
  size: number;
  type: string;
  url?: string;
  storagePath?: string;
  isUploaded?: boolean;
}

interface Invoice {
  id: string;
  invoiceNumber?: string;
  providerName: string;
  amount: number;
  issueDate: string;
  receptionDate: string;
  cufeCude?: string;
  items: Array<{
    description: string;
    quantity: number;
    price: number;
  }>;
  custodiaContabilidad?: boolean;
  recibidoContabilidad?: boolean;
  recibidoCCR?: boolean;
  fechaCustodiaContabilidad?: string;
  fechaRecibidoContabilidad?: string;
  fechaRecibidoCCR?: string;
  attachedFiles?: AttachedFile[];
}

interface InvoiceListProps {
  invoices: Invoice[];
  onViewInvoice: (invoiceId: string) => void;
  onDeleteInvoice?: (invoiceId: string) => void;
  onBulkDeleteInvoices?: (invoiceIds: string[]) => void;
  onUpdateInvoiceStatus?: (invoiceId: string, field: string, value: boolean) => void;
  compact?: boolean;
}

const InvoiceList = ({ 
  invoices, 
  onViewInvoice, 
  onDeleteInvoice, 
  onBulkDeleteInvoices,
  onUpdateInvoiceStatus,
  compact = false 
}: InvoiceListProps) => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [invoiceToDelete, setInvoiceToDelete] = useState<string | null>(null);
  const [passwordDialogOpen, setPasswordDialogOpen] = useState(false);
  const [bulkDeleteDialogOpen, setBulkDeleteDialogOpen] = useState(false);
  const [selectedInvoices, setSelectedInvoices] = useState<string[]>([]);
  const [pendingStatusChange, setPendingStatusChange] = useState<{
    invoiceId: string;
    field: string;
    value: boolean;
    checkboxName: string;
  } | null>(null);

  // Memoize filtered invoices to avoid recalculating on every render
  const filteredInvoices = useMemo(() => {
    if (!searchTerm.trim()) return invoices;
    
    const searchLower = searchTerm.toLowerCase();
    return invoices.filter(invoice => {
      const invoiceNumber = invoice.invoiceNumber || invoice.id;
      const cufeCude = invoice.cufeCude || '';
      return invoice.providerName.toLowerCase().includes(searchLower) ||
             invoiceNumber.toLowerCase().includes(searchLower) ||
             cufeCude.toLowerCase().includes(searchLower);
    });
  }, [invoices, searchTerm]);

  const handleSelectInvoice = useCallback((invoiceId: string, checked: boolean) => {
    if (checked) {
      setSelectedInvoices(prev => [...prev, invoiceId]);
    } else {
      setSelectedInvoices(prev => prev.filter(id => id !== invoiceId));
    }
  }, []);

  const handleSelectAll = useCallback((checked: boolean) => {
    if (checked) {
      setSelectedInvoices(filteredInvoices.map(invoice => invoice.id));
    } else {
      setSelectedInvoices([]);
    }
  }, [filteredInvoices]);

  const handleBulkDelete = () => {
    if (selectedInvoices.length > 0) {
      setBulkDeleteDialogOpen(true);
    }
  };

  const handleBulkDeleteConfirm = () => {
    if (onBulkDeleteInvoices && selectedInvoices.length > 0) {
      onBulkDeleteInvoices(selectedInvoices);
      setSelectedInvoices([]);
    }
    setBulkDeleteDialogOpen(false);
  };

  const handleDeleteClick = (invoiceId: string) => {
    setInvoiceToDelete(invoiceId);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = () => {
    if (invoiceToDelete && onDeleteInvoice) {
      onDeleteInvoice(invoiceToDelete);
    }
    setInvoiceToDelete(null);
  };

  const handleDeleteCancel = () => {
    setDeleteDialogOpen(false);
    setInvoiceToDelete(null);
  };

  const getCheckboxName = useCallback((field: string) => {
    const names: { [key: string]: string } = {
      'custodiaContabilidad': 'Custodia de Contabilidad',
      'recibidoContabilidad': 'Recibido por Contabilidad',
      'recibidoCCR': 'Recibido por CCR'
    };
    return names[field] || field;
  }, []);

  const handleCheckboxChange = useCallback((invoiceId: string, field: string, checked: boolean) => {
    if (onUpdateInvoiceStatus) {
      // Verificar autorización para usuarios de recepción
      if (user?.email === "recepcion@tauroquimica.co") {
        const restrictedFields = ['custodiaContabilidad', 'recibidoContabilidad', 'recibidoCCR'];
        if (restrictedFields.includes(field)) {
          toast({
            title: "Acceso restringido",
            description: "No tiene autorización para realizar esta verificación",
            variant: "destructive",
          });
          return;
        }
      }

    // Verificar autorización para usuarios de CCR
    if (user?.email === "ccr@tauroquimica.co") {
      const restrictedFields = ['custodiaContabilidad', 'recibidoContabilidad'];
      if (restrictedFields.includes(field)) {
        toast({
          title: "Acceso restringido",
          description: "No tiene autorización para realizar esta verificación",
          variant: "destructive",
        });
        return;
      }
    }

    // Verificar autorización para usuarios de contabilidad
    if (user?.email === "contabilidad@tauroquimica.co") {
      const restrictedFields = ['recibidoCCR'];
      if (restrictedFields.includes(field)) {
        toast({
          title: "Acceso restringido",
          description: "No tiene autorización para realizar esta verificación",
          variant: "destructive",
        });
        return;
      }
    }

      const currentValue = invoices.find(inv => inv.id === invoiceId)?.[field as keyof Invoice] as boolean;
      
      // Si está marcado y se quiere desmarcar, pedir contraseña
      if (currentValue && !checked) {
        setPendingStatusChange({
          invoiceId,
          field,
          value: checked,
          checkboxName: getCheckboxName(field)
        });
        setPasswordDialogOpen(true);
      } else {
        // Si no está marcado, permitir marcar sin contraseña
        onUpdateInvoiceStatus(invoiceId, field, checked);
      }
    }
  }, [invoices, onUpdateInvoiceStatus, getCheckboxName, navigate, user, toast]);

  const handlePasswordConfirm = () => {
    if (pendingStatusChange && onUpdateInvoiceStatus) {
      onUpdateInvoiceStatus(
        pendingStatusChange.invoiceId,
        pendingStatusChange.field,
        pendingStatusChange.value
      );
    }
    setPendingStatusChange(null);
  };

  const handlePasswordCancel = () => {
    setPasswordDialogOpen(false);
    setPendingStatusChange(null);
  };

  const formatDateTime = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
  };

  const getProcessingSteps = useCallback((invoice: Invoice) => {
    return [
      {
        name: "Custodia Contabilidad",
        field: "custodiaContabilidad",
        completed: invoice.custodiaContabilidad,
        date: invoice.fechaCustodiaContabilidad
      },
      {
        name: "Recibido Contabilidad", 
        field: "recibidoContabilidad",
        completed: invoice.recibidoContabilidad,
        date: invoice.fechaRecibidoContabilidad
      },
      {
        name: "Recibido CCR",
        field: "recibidoCCR",
        completed: invoice.recibidoCCR,
        date: invoice.fechaRecibidoCCR
      }
    ];
  }, []);

  // Memoize selection calculations
  const { isAllSelected, isIndeterminate } = useMemo(() => ({
    isAllSelected: filteredInvoices.length > 0 && selectedInvoices.length === filteredInvoices.length,
    isIndeterminate: selectedInvoices.length > 0 && selectedInvoices.length < filteredInvoices.length
  }), [filteredInvoices.length, selectedInvoices.length]);

  return (
    <div className="space-y-4">
      {!compact && (
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Buscar por proveedor, número de factura o CUFE/CUDE..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-white border-gray-200"
            />
          </div>
          {selectedInvoices.length > 0 && (
            <Button
              onClick={handleBulkDelete}
              variant="outline"
              className="border-red-200 text-red-600 hover:bg-red-50"
            >
              <Trash className="h-4 w-4 mr-2" />
              Eliminar Seleccionadas ({selectedInvoices.length})
            </Button>
          )}
        </div>
      )}

      {!compact && filteredInvoices.length > 0 && (
        <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
          <Checkbox
            checked={isAllSelected}
            onCheckedChange={handleSelectAll}
            className="h-4 w-4"
          />
          <label className="text-sm font-medium text-gray-700">
            Seleccionar todas las facturas
          </label>
        </div>
      )}

      <div className="space-y-3">
        {filteredInvoices.map((invoice) => {
          const displayInvoiceNumber = invoice.invoiceNumber || invoice.id;
          const isSelected = selectedInvoices.includes(invoice.id);
          
          return (
            <div
              key={invoice.id}
              className={`bg-white rounded-lg border p-4 hover:shadow-md transition-all duration-200 ${
                isSelected ? 'border-blue-300 bg-blue-50' : 'border-gray-200'
              }`}
            >
              <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    {!compact && (
                      <Checkbox
                        checked={isSelected}
                        onCheckedChange={(checked) => handleSelectInvoice(invoice.id, checked as boolean)}
                        className="h-4 w-4"
                      />
                    )}
                    <h3 className="font-semibold text-slate-900">{displayInvoiceNumber}</h3>
                    {invoice.attachedFiles && invoice.attachedFiles.length > 0 && (
                      <div className="flex items-center gap-1 text-slate-500" title={`${invoice.attachedFiles.length} archivo(s) adjunto(s)`}>
                        <Paperclip className="h-4 w-4" />
                        <span className="text-xs font-medium">{invoice.attachedFiles.length}</span>
                      </div>
                    )}
                  </div>
                  <p className="text-slate-600 font-medium">{invoice.providerName}</p>
                  <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 text-sm text-slate-500 mt-1">
                    <span>Fecha Recepción: {new Date(invoice.receptionDate.replace(/-/g, '\/')).toLocaleDateString()}</span>
                  </div>
                </div>
                
                <div className="flex flex-col lg:flex-row items-start lg:items-center gap-4">
                  <div className="flex-1 lg:min-w-[400px]">
                    <div className="space-y-3">
                      {getProcessingSteps(invoice).map((step, index) => (
                        <div key={index} className="flex items-center justify-between p-2 rounded-md bg-gray-50">
                          <div className="flex items-center gap-3">
                            <Checkbox
                              id={`${invoice.id}-${step.field}`}
                              checked={step.completed || false}
                              onCheckedChange={(checked) => 
                                handleCheckboxChange(invoice.id, step.field, checked as boolean)
                              }
                              className="h-4 w-4"
                            />
                            <label 
                              htmlFor={`${invoice.id}-${step.field}`}
                              className={`text-sm font-medium cursor-pointer ${
                                step.completed ? 'text-green-700' : 'text-gray-600'
                              }`}
                            >
                              {step.name}
                            </label>
                          </div>
                          {step.completed && step.date && (
                            <span className="text-xs text-gray-500">
                              {formatDateTime(step.date)}
                            </span>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button
                      onClick={() => onViewInvoice(invoice.id)}
                      variant="outline"
                      size="sm"
                      className="border-blue-200 text-blue-600 hover:bg-blue-50"
                    >
                      <Edit className="h-4 w-4 mr-2" />
                      Editar
                    </Button>
                    {onDeleteInvoice && (
                      <Button
                        onClick={() => handleDeleteClick(invoice.id)}
                        variant="outline"
                        size="sm"
                        className="border-red-200 text-red-600 hover:bg-red-50"
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Eliminar
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })}

        {filteredInvoices.length === 0 && (
          <div className="text-center py-8">
            <p className="text-slate-500">No se encontraron facturas que coincidan con los filtros.</p>
          </div>
        )}
      </div>

      <DeleteInvoiceDialog
        isOpen={deleteDialogOpen}
        onClose={handleDeleteCancel}
        onConfirm={handleDeleteConfirm}
        invoiceId={invoiceToDelete || ""}
      />

      <BulkDeleteDialog
        isOpen={bulkDeleteDialogOpen}
        onClose={() => setBulkDeleteDialogOpen(false)}
        onConfirm={handleBulkDeleteConfirm}
        selectedCount={selectedInvoices.length}
      />

      <PasswordConfirmDialog
        isOpen={passwordDialogOpen}
        onClose={handlePasswordCancel}
        onConfirm={handlePasswordConfirm}
        title="Confirmar acción"
        description={
          pendingStatusChange 
            ? `¿Estás seguro que deseas remover la verificación de "${pendingStatusChange.checkboxName}"?`
            : ""
        }
      />
    </div>
  );
};

export default memo(InvoiceList);
