
const InvoiceTerms = () => {
  return (
    <div className="pt-8 border-t border-gray-200">
      <h3 className="font-semibold text-slate-900 mb-3">Observaciones:</h3>
      <div className="text-sm text-slate-600 space-y-2">
        <p>• El pago debe realizarse dentro de los 15 días posteriores a la fecha de vencimiento.</p>
        <p>• Los pagos tardíos pueden estar sujetos a cargos por intereses.</p>
        <p>• Esta factura es válida sin firma física según las regulaciones de facturación electrónica.</p>
      </div>
    </div>
  );
};

export default InvoiceTerms;
