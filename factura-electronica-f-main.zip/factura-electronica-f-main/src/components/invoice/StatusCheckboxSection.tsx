
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import PasswordConfirmDialog from "../PasswordConfirmDialog";

interface StatusCheckboxSectionProps {
  custodiaContabilidad: boolean;
  recibidoContabilidad: boolean;
  recibidoCCR: boolean;
  fechaCustodiaContabilidad: string;
  fechaRecibidoContabilidad: string;
  fechaRecibidoCCR: string;
  onCustodiaContabilidadChange: (checked: boolean) => void;
  onRecibidoContabilidadChange: (checked: boolean) => void;
  onRecibidoCCRChange: (checked: boolean) => void;
}

const StatusCheckboxSection = ({
  custodiaContabilidad,
  recibidoContabilidad,
  recibidoCCR,
  fechaCustodiaContabilidad,
  fechaRecibidoContabilidad,
  fechaRecibidoCCR,
  onCustodiaContabilidadChange,
  onRecibidoContabilidadChange,
  onRecibidoCCRChange
}: StatusCheckboxSectionProps) => {
  const { user } = useAuth();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [pendingAction, setPendingAction] = useState<(() => void) | null>(null);
  const [dialogInfo, setDialogInfo] = useState({ title: "", description: "" });

  const handleCheckboxChange = (
    currentValue: boolean,
    onChange: (checked: boolean) => void,
    checkboxName: string
  ) => {
    // Verificar autorización para usuarios de recepción
    if (user?.email === "recepcion@tauroquimica.co") {
      const restrictedCheckboxes = ['Custodia de Contabilidad', 'Recibido por Contabilidad', 'Recibido por CCR'];
      if (restrictedCheckboxes.includes(checkboxName)) {
        toast({
          title: "Acceso restringido",
          description: "No tiene autorización para realizar esta verificación",
          variant: "destructive",
        });
        return;
      }
    }

    // Verificar autorización para usuarios de CCR
    if (user?.email === "ccr@tauroquimica.co") {
      const restrictedCheckboxes = ['Custodia de Contabilidad', 'Recibido por Contabilidad'];
      if (restrictedCheckboxes.includes(checkboxName)) {
        toast({
          title: "Acceso restringido",
          description: "No tiene autorización para realizar esta verificación",
          variant: "destructive",
        });
        return;
      }
    }

    // Verificar autorización para usuarios de contabilidad
    if (user?.email === "contabilidad@tauroquimica.co") {
      const restrictedCheckboxes = ['Recibido por CCR'];
      if (restrictedCheckboxes.includes(checkboxName)) {
        toast({
          title: "Acceso restringido",
          description: "No tiene autorización para realizar esta verificación",
          variant: "destructive",
        });
        return;
      }
    }

    console.log(`StatusCheckboxSection: ${checkboxName} clicked - current value: ${currentValue}, will change to: ${!currentValue}`);
    
    // Si está marcado y se quiere desmarcar, pedir contraseña
    if (currentValue) {
      setDialogInfo({
        title: "Confirmar acción",
        description: `¿Estás seguro que deseas remover la verificación de "${checkboxName}"?`,
      });
      setPendingAction(() => () => {
        console.log(`StatusCheckboxSection: Confirming ${checkboxName} change to false`);
        onChange(false);
      });
      setDialogOpen(true);
    } else {
      // Si no está marcado, permitir marcar sin contraseña
      console.log(`StatusCheckboxSection: Setting ${checkboxName} to true`);
      onChange(true);
    }
  };

  const handleConfirmAction = () => {
    if (pendingAction) {
      pendingAction();
      setPendingAction(null);
    }
  };

  const handleCloseDialog = () => {
    setDialogOpen(false);
    setPendingAction(null);
  };

  const formatDateTime = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
  };

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Estado de Procesamiento</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center space-x-2">
            <Checkbox
              id="custodiaContabilidad"
              checked={custodiaContabilidad}
              onCheckedChange={() =>
                handleCheckboxChange(
                  custodiaContabilidad,
                  onCustodiaContabilidadChange,
                  "Custodia de Contabilidad"
                )
              }
            />
            <Label htmlFor="custodiaContabilidad" className="flex-1">
              Custodia de Contabilidad
            </Label>
            {custodiaContabilidad && fechaCustodiaContabilidad && (
              <span className="text-sm text-gray-600">
                {formatDateTime(fechaCustodiaContabilidad)}
              </span>
            )}
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="recibidoContabilidad"
              checked={recibidoContabilidad}
              onCheckedChange={() =>
                handleCheckboxChange(
                  recibidoContabilidad,
                  onRecibidoContabilidadChange,
                  "Recibido por Contabilidad"
                )
              }
            />
            <Label htmlFor="recibidoContabilidad" className="flex-1">
              Recibido por Contabilidad
            </Label>
            {recibidoContabilidad && fechaRecibidoContabilidad && (
              <span className="text-sm text-gray-600">
                {formatDateTime(fechaRecibidoContabilidad)}
              </span>
            )}
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="recibidoCCR"
              checked={recibidoCCR}
              onCheckedChange={() =>
                handleCheckboxChange(
                  recibidoCCR,
                  onRecibidoCCRChange,
                  "Recibido por CCR"
                )
              }
            />
            <Label htmlFor="recibidoCCR" className="flex-1">
              Recibido por CCR
            </Label>
            {recibidoCCR && fechaRecibidoCCR && (
              <span className="text-sm text-gray-600">
                {formatDateTime(fechaRecibidoCCR)}
              </span>
            )}
          </div>
        </CardContent>
      </Card>

      <PasswordConfirmDialog
        isOpen={dialogOpen}
        onClose={handleCloseDialog}
        onConfirm={handleConfirmAction}
        title={dialogInfo.title}
        description={dialogInfo.description}
      />
    </>
  );
};

export default StatusCheckboxSection;
