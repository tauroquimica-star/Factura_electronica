
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface ProviderInfoSectionProps {
  providerName: string;
  nitProveedor: string;
  onProviderNameChange: (value: string) => void;
  onNitChange: (value: string) => void;
}

const ProviderInfoSection = ({ 
  providerName, 
  nitProveedor, 
  onProviderNameChange, 
  onNitChange 
}: ProviderInfoSectionProps) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Información del Proveedor</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="providerName">Nombre del Proveedor *</Label>
            <Input
              id="providerName"
              name="providerName"
              value={providerName}
              onChange={(e) => onProviderNameChange(e.target.value)}
              placeholder="Ingresa el nombre del proveedor"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="nitProveedor">NIT Proveedor *</Label>
            <Input
              id="nitProveedor"
              name="nitProveedor"
              value={nitProveedor}
              onChange={(e) => onNitChange(e.target.value)}
              placeholder="Ingresa el NIT del proveedor"
              required
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ProviderInfoSection;
