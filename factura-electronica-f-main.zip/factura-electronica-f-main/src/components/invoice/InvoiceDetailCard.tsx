import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import AttachedFilesDisplay from "./AttachedFilesDisplay";
import InvoiceTerms from "./InvoiceTerms";

interface AttachedFile {
  id: string;
  name: string;
  size: number;
  type: string;
  url?: string;
  storagePath?: string;
  isUploaded?: boolean;
}

interface Invoice {
  id: string;
  providerName: string;
  amount: number;
  issueDate: string;
  receptionDate: string;
  items: Array<{
    description: string;
    quantity: number;
    price: number;
  }>;
  cufeCude?: string;
  custodio?: string;
  attachedFiles?: AttachedFile[];
}

interface InvoiceDetailCardProps {
  invoice: Invoice;
}

const InvoiceDetailCard = ({ invoice }: InvoiceDetailCardProps) => {
  return (
    <Card className="border-0 shadow-xl bg-white">
      <CardHeader className="pb-8">
        <div className="flex flex-col md:flex-row justify-between items-start gap-6">
          <div>
            <CardTitle className="text-3xl font-bold text-slate-900 mb-2">
              FACTURA
            </CardTitle>
            <p className="text-lg text-slate-600">{invoice.id}</p>
            {invoice.cufeCude && (
              <p className="text-sm text-slate-500 mt-1">
                CUFE/CUDE: {invoice.cufeCude}
              </p>
            )}
          </div>
          
          <div className="text-right">
            <h2 className="text-2xl font-bold text-slate-900 mb-2">Mi Empresa</h2>
            <div className="text-slate-600 space-y-1">
              <p>Calle Principal 123</p>
              <p>Ciudad, Estado 12345</p>
              <p>email@miempresa.com</p>
              <p>+1 (555) 123-4567</p>
            </div>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-8">
        {/* Provider and dates info */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h3 className="font-semibold text-slate-900 mb-3">Proveedor:</h3>
            <div className="text-slate-600 space-y-1">
              <p className="font-medium text-lg">{invoice.providerName}</p>
              <p>NIT: 123456789-1</p>
              <p>Dirección del proveedor</p>
              <p>Ciudad, Estado</p>
              {invoice.custodio && (
                <p>Custodio: {invoice.custodio}</p>
              )}
            </div>
          </div>
          
          <div className="md:text-right">
            <h3 className="font-semibold text-slate-900 mb-2">Fecha de recepción:</h3>
            <p className="text-slate-600">{new Date(invoice.receptionDate.replace(/-/g, '\/')).toLocaleDateString()}</p>
          </div>
        </div>

        <Separator />

        {/* Items table */}
        <div>
          <h3 className="font-semibold text-slate-900 mb-4">Detalles de la factura:</h3>
          <div className="border border-gray-200 rounded-lg overflow-hidden">
            <table className="w-full">
              <thead className="bg-slate-50">
                <tr>
                  <th className="px-4 py-3 text-left font-medium text-slate-900">Descripción</th>
                  <th className="px-4 py-3 text-right font-medium text-slate-900">Valor a pagar</th>
                </tr>
              </thead>
              <tbody>
                {invoice.items.map((item, index) => (
                  <tr key={index} className="border-t border-gray-200">
                    <td className="px-4 py-4 text-slate-900">{item.description}</td>
                    <td className="px-4 py-4 text-right font-medium text-slate-900">
                      ${item.price.toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Attached Files Section */}
        <AttachedFilesDisplay attachedFiles={invoice.attachedFiles || []} />

        {/* Terms */}
        <InvoiceTerms />
      </CardContent>
    </Card>
  );
};

export default InvoiceDetailCard;
