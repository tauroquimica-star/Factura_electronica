
import { memo, useCallback } from 'react';
import { Checkbox } from "@/components/ui/checkbox";

interface InvoiceStatusManagerProps {
  invoiceId: string;
  field: string;
  checked: boolean;
  label: string;
  date?: string;
  onCheckboxChange: (invoiceId: string, field: string, checked: boolean) => void;
  formatDateTime: (dateString: string) => string;
}

const InvoiceStatusManager = memo(({
  invoiceId,
  field,
  checked,
  label,
  date,
  onCheckboxChange,
  formatDateTime
}: InvoiceStatusManagerProps) => {
  const handleChange = useCallback((newChecked: boolean) => {
    onCheckboxChange(invoiceId, field, newChecked);
  }, [invoiceId, field, onCheckboxChange]);

  return (
    <div className="flex items-center justify-between p-1 rounded-md bg-gray-50">
      <div className="flex items-center gap-2">
        <Checkbox
          id={`${invoiceId}-${field}`}
          checked={checked || false}
          onCheckedChange={handleChange}
          className="h-3 w-3"
        />
        <label 
          htmlFor={`${invoiceId}-${field}`}
          className={`text-xs font-medium cursor-pointer ${
            checked ? 'text-green-700' : 'text-gray-600'
          }`}
        >
          {label}
        </label>
      </div>
      {checked && date && (
        <span className="text-xs text-gray-500">
          {formatDateTime(date)}
        </span>
      )}
    </div>
  );
});

InvoiceStatusManager.displayName = 'InvoiceStatusManager';

export default InvoiceStatusManager;
