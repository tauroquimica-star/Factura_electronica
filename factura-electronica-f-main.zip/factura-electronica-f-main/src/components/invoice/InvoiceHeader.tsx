
import { FileText } from "lucide-react";

const InvoiceHeader = () => {
  return (
    <div className="mb-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold text-slate-900 mb-2">
            Gestión de Facturas
          </h1>
          <p className="text-slate-600">
            Administra tus facturas electrónicas de manera eficiente
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <FileText className="h-8 w-8 text-blue-600" />
        </div>
      </div>
    </div>
  );
};

export default InvoiceHeader;
