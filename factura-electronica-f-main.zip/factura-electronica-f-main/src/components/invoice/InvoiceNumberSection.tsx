
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Lock } from "lucide-react";

interface InvoiceNumberSectionProps {
  invoiceNumber: string;
  onChange: (value: string) => void;
  isLocked: boolean;
}

const InvoiceNumberSection = ({ invoiceNumber, onChange, isLocked }: InvoiceNumberSectionProps) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          Número de Factura
          {isLocked && <Lock className="h-4 w-4 text-gray-500" />}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <Label htmlFor="invoiceNumber">Número de Factura *</Label>
          <Input
            id="invoiceNumber"
            name="invoiceNumber"
            value={invoiceNumber}
            onChange={(e) => onChange(e.target.value)}
            placeholder="Ingresa el número de factura"
            required
            disabled={isLocked}
            className={isLocked ? "bg-gray-100 cursor-not-allowed" : ""}
          />
        </div>
      </CardContent>
    </Card>
  );
};

export default InvoiceNumberSection;
