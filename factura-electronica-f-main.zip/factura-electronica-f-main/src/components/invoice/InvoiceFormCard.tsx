
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import CreateInvoiceForm from "@/components/CreateInvoiceForm";

interface InvoiceFormCardProps {
  editingInvoice: any;
  onSubmit: (invoice: any) => void;
  onCancel: () => void;
}

const InvoiceFormCard = ({ editingInvoice, onSubmit, onCancel }: InvoiceFormCardProps) => {
  return (
    <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-slate-900">
              {editingInvoice ? "Editar Factura" : "Nueva Factura"}
            </CardTitle>
            <CardDescription>
              {editingInvoice ? "Modifica la factura existente" : "Crea una nueva factura electrónica"}
            </CardDescription>
          </div>
          <Button onClick={onCancel} variant="outline">
            Cancelar
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <CreateInvoiceForm 
          onSubmit={onSubmit}
          editingInvoice={editingInvoice}
          isEditing={!!editingInvoice}
        />
      </CardContent>
    </Card>
  );
};

export default InvoiceFormCard;
