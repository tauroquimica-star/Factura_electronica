import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Download, Trash2, Upload, Loader2, FileText } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface AttachedFile {
  id: string;
  name: string;
  size: number;
  type: string;
  url?: string;
  file?: File;
  storagePath?: string;
  isUploaded?: boolean;
}

interface AttachedFilesSectionProps {
  attachedFiles: AttachedFile[];
  onFilesChange: (files: AttachedFile[]) => void;
  invoiceId?: string;
}

const AttachedFilesSection = ({ attachedFiles, onFilesChange, invoiceId }: AttachedFilesSectionProps) => {
  const { toast } = useToast();
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    // Validate file types and sizes
    const allowedTypes = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'image/jpeg',
      'image/jpg',
      'image/png',
      'image/gif',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    ];

    const maxSize = 10 * 1024 * 1024; // 10MB

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (!allowedTypes.includes(file.type)) {
        toast({
          title: "Tipo de archivo no permitido",
          description: `El archivo ${file.name} no tiene un formato permitido`,
          variant: "destructive"
        });
        event.target.value = '';
        return;
      }
      if (file.size > maxSize) {
        toast({
          title: "Archivo muy grande",
          description: `El archivo ${file.name} es muy grande (máximo 10MB)`,
          variant: "destructive"
        });
        event.target.value = '';
        return;
      }
    }

    setUploading(true);
    setUploadProgress(0);
    
    try {
      const newFiles: AttachedFile[] = [];
      const totalFiles = files.length;

      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const fileId = crypto.randomUUID();
        const fileExtension = file.name.split('.').pop();
        const fileName = `${fileId}.${fileExtension}`;
        const storagePath = invoiceId ? `${invoiceId}/${fileName}` : `temp/${fileName}`;

        let url = URL.createObjectURL(file);
        let isUploaded = false;

        // Update progress
        const currentProgress = Math.round(((i + 1) / totalFiles) * 100);
        setUploadProgress(currentProgress);

        // If we have an invoiceId, upload to Supabase Storage
        if (invoiceId) {
          try {
            console.log('Uploading file to storage:', storagePath);
            
            const { error: uploadError } = await supabase.storage
              .from('invoice-attachments')
              .upload(storagePath, file, {
                cacheControl: '3600',
                upsert: false
              });

            if (uploadError) {
              console.error('Upload error:', uploadError);
              throw uploadError;
            }

            // Get public URL
            const { data: urlData } = supabase.storage
              .from('invoice-attachments')
              .getPublicUrl(storagePath);

            url = urlData.publicUrl;
            isUploaded = true;

            console.log('File uploaded successfully, saving to database...');

            // Save to database
            const { error: dbError } = await supabase
              .from('invoice_attachments')
              .insert({
                id: fileId,
                invoice_id: invoiceId,
                file_name: file.name,
                file_size: file.size,
                file_type: file.type,
                storage_path: storagePath
              });

            if (dbError) {
              console.error('Database error:', dbError);
              throw dbError;
            }

            console.log('File saved to database successfully');
          } catch (error) {
            console.error('Error uploading file:', error);
            toast({
              title: "Error al subir archivo",
              description: `No se pudo subir ${file.name}: ${error.message}`,
              variant: "destructive"
            });
            continue;
          }
        }

        newFiles.push({
          id: fileId,
          name: file.name,
          size: file.size,
          type: file.type,
          file: isUploaded ? undefined : file,
          url,
          storagePath,
          isUploaded
        });
      }

      if (newFiles.length > 0) {
        onFilesChange([...attachedFiles, ...newFiles]);
        
        toast({
          title: "Archivos adjuntados",
          description: `Se han adjuntado ${newFiles.length} archivo(s) exitosamente`
        });
      }
    } catch (error) {
      console.error('Error in file upload:', error);
      toast({
        title: "Error",
        description: "Error al procesar los archivos",
        variant: "destructive"
      });
    } finally {
      setUploading(false);
      setUploadProgress(0);
    }

    // Reset input
    event.target.value = '';
  };

  const handleRemoveFile = async (fileId: string) => {
    const fileToRemove = attachedFiles.find(f => f.id === fileId);
    if (!fileToRemove) return;

    try {
      // If the file is in storage, remove it
      if (fileToRemove.storagePath && fileToRemove.isUploaded) {
        console.log('Removing file from storage:', fileToRemove.storagePath);
        
        const { error: storageError } = await supabase.storage
          .from('invoice-attachments')
          .remove([fileToRemove.storagePath]);

        if (storageError) {
          console.error('Storage error:', storageError);
          throw storageError;
        }

        // Remove from database
        const { error: dbError } = await supabase
          .from('invoice_attachments')
          .delete()
          .eq('id', fileId);

        if (dbError) {
          console.error('Database error:', dbError);
          throw dbError;
        }
      }

      // If it's a blob URL, revoke it
      if (fileToRemove.url && fileToRemove.url.startsWith('blob:')) {
        URL.revokeObjectURL(fileToRemove.url);
      }
      
      const updatedFiles = attachedFiles.filter(file => file.id !== fileId);
      onFilesChange(updatedFiles);
      
      toast({
        title: "Archivo eliminado",
        description: "El archivo ha sido eliminado exitosamente"
      });
    } catch (error) {
      console.error('Error removing file:', error);
      toast({
        title: "Error",
        description: "No se pudo eliminar el archivo",
        variant: "destructive"
      });
    }
  };

  const handleDownloadFile = async (file: AttachedFile) => {
    try {
      let downloadUrl = file.url;

      // If the file is in storage, download it properly
      if (file.storagePath && file.isUploaded) {
        const { data, error } = await supabase.storage
          .from('invoice-attachments')
          .download(file.storagePath);

        if (error) throw error;

        downloadUrl = URL.createObjectURL(data);
      }

      if (downloadUrl) {
        const link = document.createElement('a');
        link.href = downloadUrl;
        link.download = file.name;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        // If we created a temporary URL, revoke it after download
        if (downloadUrl !== file.url) {
          setTimeout(() => URL.revokeObjectURL(downloadUrl!), 1000);
        }
        
        toast({
          title: "Descargando archivo",
          description: `Descargando ${file.name}...`
        });
      }
    } catch (error) {
      console.error('Error downloading file:', error);
      toast({
        title: "Error",
        description: "No se pudo descargar el archivo",
        variant: "destructive"
      });
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getFileIcon = (fileType: string) => {
    if (fileType.includes('pdf')) return '📄';
    if (fileType.includes('image')) return '🖼️';
    if (fileType.includes('word') || fileType.includes('document')) return '📝';
    if (fileType.includes('excel') || fileType.includes('spreadsheet')) return '📊';
    return '📎';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Upload className="h-5 w-5" />
          Archivos Adjuntos
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="file-upload" className="block text-sm font-medium mb-2">
            Seleccionar archivos
          </Label>
          <div className="flex items-center gap-2">
            <Input
              id="file-upload"
              type="file"
              multiple
              onChange={handleFileUpload}
              className="flex-1"
              accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.gif,.xlsx,.xls"
              disabled={uploading}
            />
            <Button 
              type="button" 
              variant="outline" 
              size="sm" 
              disabled={uploading}
              className="min-w-[100px]"
              onClick={() => document.getElementById('file-upload')?.click()}
            >
              {uploading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Subiendo...
                </>
              ) : (
                <>
                  <Upload className="h-4 w-4 mr-2" />
                  Adjuntar
                </>
              )}
            </Button>
          </div>
          
          {uploading && (
            <div className="mt-2">
              <Progress value={uploadProgress} className="w-full" />
              <p className="text-xs text-gray-500 mt-1">
                Subiendo archivos... {uploadProgress}%
              </p>
            </div>
          )}
          
          <p className="text-xs text-gray-500 mt-1">
            Formatos permitidos: PDF, DOC, DOCX, JPG, PNG, GIF, XLSX, XLS (máximo 10MB por archivo)
          </p>
        </div>

        {attachedFiles.length > 0 && (
          <div className="space-y-2">
            <Label className="text-sm font-medium">Archivos adjuntados ({attachedFiles.length}):</Label>
            <div className="border border-gray-200 rounded-lg">
              {attachedFiles.map((file, index) => (
                <div
                  key={file.id}
                  className={`flex items-center justify-between p-3 hover:bg-gray-50 transition-colors ${
                    index !== attachedFiles.length - 1 ? 'border-b border-gray-200' : ''
                  }`}
                >
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    <span className="text-lg">{getFileIcon(file.type)}</span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 truncate">
                        {file.name}
                        {file.isUploaded && (
                          <span className="ml-2 text-xs text-green-600 font-normal">✓ Guardado</span>
                        )}
                        {!file.isUploaded && invoiceId && (
                          <span className="ml-2 text-xs text-orange-600 font-normal">⏳ Pendiente</span>
                        )}
                      </p>
                      <p className="text-xs text-gray-500">
                        {formatFileSize(file.size)} • {file.type.split('/')[1]?.toUpperCase()}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 ml-4">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => handleDownloadFile(file)}
                      className="border-blue-200 text-blue-600 hover:bg-blue-50"
                      title="Descargar archivo"
                    >
                      <Download className="h-4 w-4" />
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => handleRemoveFile(file.id)}
                      className="border-red-200 text-red-600 hover:bg-red-50"
                      title="Eliminar archivo"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default AttachedFilesSection;
