
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

interface ObservationsSectionProps {
  observations: string;
  onChange: (value: string) => void;
  observationsUser?: string;
  observationsDate?: string;
}

const ObservationsSection = ({ observations, onChange, observationsUser, observationsDate }: ObservationsSectionProps) => {
  const formatDateTime = (dateString?: string) => {
    if (!dateString) return '';
    return new Date(dateString).toLocaleString('es-ES', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Observaciones</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="observations">Observaciones</Label>
            {observationsUser && observationsDate && (
              <span className="text-xs text-muted-foreground">
                ({observationsUser} - {formatDateTime(observationsDate)})
              </span>
            )}
          </div>
          <Textarea
            id="observations"
            name="observations"
            value={observations}
            onChange={(e) => onChange(e.target.value)}
            placeholder="Observaciones adicionales..."
            rows={4}
          />
        </div>
      </CardContent>
    </Card>
  );
};

export default ObservationsSection;
