
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Trash2 } from "lucide-react";

interface InvoiceItem {
  description: string;
  quantity: number;
  price: number;
}

interface InvoiceItemsSectionProps {
  items: InvoiceItem[];
  onItemChange: (index: number, field: keyof InvoiceItem, value: string | number) => void;
  onAddItem: () => void;
  onRemoveItem: (index: number) => void;
}

const InvoiceItemsSection = ({ 
  items, 
  onItemChange, 
  onAddItem, 
  onRemoveItem 
}: InvoiceItemsSectionProps) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Items de la Factura</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {items.map((item, index) => (
          <div key={index} className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 border rounded-lg">
            <div className="md:col-span-2 space-y-2">
              <Label htmlFor={`description-${index}`}>Descripción</Label>
              <Input
                id={`description-${index}`}
                value={item.description}
                onChange={(e) => onItemChange(index, "description", e.target.value)}
                placeholder="Descripción del item"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor={`quantity-${index}`}>Cantidad</Label>
              <Input
                id={`quantity-${index}`}
                type="number"
                min="1"
                value={item.quantity}
                onChange={(e) => onItemChange(index, "quantity", parseInt(e.target.value) || 1)}
                placeholder="1"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor={`price-${index}`}>Valor a pagar</Label>
              <div className="flex gap-2">
                <Input
                  id={`price-${index}`}
                  type="number"
                  min="0"
                  step="0.01"
                  value={item.price}
                  onChange={(e) => onItemChange(index, "price", parseFloat(e.target.value) || 0)}
                  placeholder="0.00"
                />
                {items.length > 1 && (
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    onClick={() => onRemoveItem(index)}
                    className="shrink-0"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </div>
          </div>
        ))}
        
        <Button
          type="button"
          variant="outline"
          onClick={onAddItem}
          className="w-full"
        >
          <Plus className="h-4 w-4 mr-2" />
          Agregar Item
        </Button>
      </CardContent>
    </Card>
  );
};

export default InvoiceItemsSection;
