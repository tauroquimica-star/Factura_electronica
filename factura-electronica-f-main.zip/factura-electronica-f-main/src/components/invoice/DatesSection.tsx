
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Lock } from "lucide-react";

interface DatesSectionProps {
  issueDate: string;
  receptionDate: string;
  onIssueDateChange: (value: string) => void;
  onReceptionDateChange: (value: string) => void;
  isReceptionDateLocked: boolean;
}

const DatesSection = ({ 
  issueDate, 
  receptionDate, 
  onIssueDateChange, 
  onReceptionDateChange, 
  isReceptionDateLocked 
}: DatesSectionProps) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Fechas</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="issueDate">Fecha de Emisión *</Label>
            <Input
              id="issueDate"
              name="issueDate"
              type="date"
              value={issueDate}
              onChange={(e) => onIssueDateChange(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="receptionDate" className="flex items-center gap-2">
              Fecha de Recepción *
              {isReceptionDateLocked && <Lock className="h-4 w-4 text-gray-500" />}
            </Label>
            <Input
              id="receptionDate"
              name="receptionDate"
              type="date"
              value={receptionDate}
              onChange={(e) => onReceptionDateChange(e.target.value)}
              required
              disabled={isReceptionDateLocked}
              className={isReceptionDateLocked ? "bg-gray-100 cursor-not-allowed" : ""}
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default DatesSection;
