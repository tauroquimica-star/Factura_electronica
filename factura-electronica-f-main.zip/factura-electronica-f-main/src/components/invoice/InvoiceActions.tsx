
import { memo } from 'react';
import { Button } from "@/components/ui/button";
import { Edit, Trash2 } from "lucide-react";

interface InvoiceActionsProps {
  invoiceId: string;
  onViewInvoice: (invoiceId: string) => void;
  onDeleteInvoice?: (invoiceId: string) => void;
}

const InvoiceActions = memo(({
  invoiceId,
  onViewInvoice,
  onDeleteInvoice
}: InvoiceActionsProps) => {
  return (
    <div className="flex gap-1">
      <Button
        onClick={() => onViewInvoice(invoiceId)}
        variant="outline"
        size="sm"
        className="border-blue-200 text-blue-600 hover:bg-blue-50 text-xs px-2"
      >
        <Edit className="h-3 w-3 mr-1" />
        Editar
      </Button>
      {onDeleteInvoice && (
        <Button
          onClick={() => onDeleteInvoice(invoiceId)}
          variant="outline"
          size="sm"
          className="border-red-200 text-red-600 hover:bg-red-50 text-xs px-2"
        >
          <Trash2 className="h-3 w-3 mr-1" />
          Eliminar
        </Button>
      )}
    </div>
  );
});

InvoiceActions.displayName = 'InvoiceActions';

export default InvoiceActions;
