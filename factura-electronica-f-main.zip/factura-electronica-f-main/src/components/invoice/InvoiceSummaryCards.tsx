interface InvoiceSummaryCardsProps {
  totalInvoices: number;
  newInvoices: number;
  createdInvoices: number;
  showTotal?: boolean;
  showCCR?: boolean;
  showContabilidad?: boolean;
}

const InvoiceSummaryCards = ({ 
  totalInvoices, 
  newInvoices, 
  createdInvoices,
  showTotal = true,
  showCCR = true,
  showContabilidad = true
}: InvoiceSummaryCardsProps) => {
  const cards = [];
  
  if (showTotal) {
    cards.push(
      <div key="total" className="bg-blue-50 rounded-lg p-4">
        <h3 className="text-sm font-medium text-blue-900 mb-1">Total Facturas</h3>
        <p className="text-2xl font-bold text-blue-800">{totalInvoices}</p>
      </div>
    );
  }
  
  if (showCCR) {
    cards.push(
      <div key="ccr" className="bg-green-50 rounded-lg p-4">
        <h3 className="text-sm font-medium text-green-900 mb-1">CCR</h3>
        <p className="text-2xl font-bold text-green-800">{newInvoices}</p>
      </div>
    );
  }
  
  if (showContabilidad) {
    cards.push(
      <div key="contabilidad" className="bg-purple-50 rounded-lg p-4">
        <h3 className="text-sm font-medium text-purple-900 mb-1">Contabilidad</h3>
        <p className="text-2xl font-bold text-purple-800">{createdInvoices}</p>
      </div>
    );
  }
  
  return (
    <div className={`grid grid-cols-1 ${cards.length === 1 ? 'md:grid-cols-1' : cards.length === 2 ? 'md:grid-cols-2' : 'md:grid-cols-3'} gap-4 mt-6`}>
      {cards}
    </div>
  );
};

export default InvoiceSummaryCards;
