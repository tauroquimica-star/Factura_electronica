
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface AdditionalInfoSectionProps {
  cufeCude: string;
  custodio: string;
  onCufeChange: (value: string) => void;
  onCustodioChange: (value: string) => void;
}

const AdditionalInfoSection = ({ 
  cufeCude, 
  custodio, 
  onCufeChange, 
  onCustodioChange 
}: AdditionalInfoSectionProps) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Información Adicional</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="cufeCude">CUFE/CUDE</Label>
            <Input
              id="cufeCude"
              name="cufeCude"
              value={cufeCude}
              onChange={(e) => onCufeChange(e.target.value)}
              placeholder="Ingresa el CUFE/CUDE"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="custodio">Custodio</Label>
            <Input
              id="custodio"
              name="custodio"
              value={custodio}
              onChange={(e) => onCustodioChange(e.target.value)}
              placeholder="Ingresa el custodio"
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default AdditionalInfoSection;
