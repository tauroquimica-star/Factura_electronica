
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Download, Paperclip } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface AttachedFile {
  id: string;
  name: string;
  size: number;
  type: string;
  url?: string;
  storagePath?: string;
  isUploaded?: boolean;
}

interface AttachedFilesDisplayProps {
  attachedFiles: AttachedFile[];
}

const AttachedFilesDisplay = ({ attachedFiles }: AttachedFilesDisplayProps) => {
  const { toast } = useToast();

  const handleDownloadAttachment = async (file: AttachedFile) => {
    try {
      if (file.url) {
        const link = document.createElement('a');
        link.href = file.url;
        link.download = file.name;
        link.target = '_blank';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        toast({
          title: "Descargando archivo",
          description: `Descargando ${file.name}...`
        });
      }
    } catch (error) {
      console.error('Error downloading file:', error);
      toast({
        title: "Error",
        description: "No se pudo descargar el archivo",
        variant: "destructive"
      });
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  if (!attachedFiles || attachedFiles.length === 0) {
    return null;
  }

  return (
    <>
      <Separator />
      <div>
        <h3 className="font-semibold text-slate-900 mb-4 flex items-center">
          <Paperclip className="h-5 w-5 mr-2" />
          Archivos Adjuntos ({attachedFiles.length})
        </h3>
        <div className="border border-gray-200 rounded-lg">
          {attachedFiles.map((file, index) => (
            <div
              key={file.id}
              className={`flex items-center justify-between p-4 ${
                index !== attachedFiles.length - 1 ? 'border-b border-gray-200' : ''
              }`}
            >
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-slate-900 truncate">
                  {file.name}
                </p>
                <p className="text-xs text-slate-500">
                  {formatFileSize(file.size)} • {file.type}
                </p>
              </div>
              <div className="flex items-center gap-2 ml-4">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => handleDownloadAttachment(file)}
                  className="border-blue-200 text-blue-600 hover:bg-blue-50"
                >
                  <Download className="h-4 w-4 mr-1" />
                  Descargar
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default AttachedFilesDisplay;
