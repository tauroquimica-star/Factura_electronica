
import { Button } from "@/components/ui/button";
import { ArrowLeft, Download, Printer } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface InvoiceDetailHeaderProps {
  onBack: () => void;
}

const InvoiceDetailHeader = ({ onBack }: InvoiceDetailHeaderProps) => {
  const { toast } = useToast();

  const handleDownloadPDF = () => {
    toast({
      title: "Descargando PDF",
      description: "El archivo PDF se está generando...",
    });
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="flex items-center justify-between mb-8">
      <Button
        onClick={onBack}
        variant="outline"
        className="border-gray-200 text-gray-600 hover:bg-gray-50"
      >
        <ArrowLeft className="h-4 w-4 mr-2" />
        Volver
      </Button>

      <div className="flex items-center gap-3">
        <div className="flex gap-2">
          <Button
            onClick={handlePrint}
            variant="outline"
            size="sm"
            className="border-gray-200 text-gray-600 hover:bg-gray-50"
          >
            <Printer className="h-4 w-4 mr-2" />
            Imprimir
          </Button>
          <Button
            onClick={handleDownloadPDF}
            variant="outline"
            size="sm"
            className="border-blue-200 text-blue-600 hover:bg-blue-50"
          >
            <Download className="h-4 w-4 mr-2" />
            PDF
          </Button>
        </div>
      </div>
    </div>
  );
};

export default InvoiceDetailHeader;
