
import { useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Upload } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';

interface InvoiceExcelUploadProps {
  onFileUpload: (file: File) => void;
  isLoading?: boolean;
}

const InvoiceExcelUpload = ({ onFileUpload, isLoading }: InvoiceExcelUploadProps) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const { user } = useAuth();

  const handleButtonClick = () => {
    if (user?.email === 'ccr@tauroquimica.co' || user?.email === 'contabilidad@tauroquimica.co') {
      toast({
        title: 'Acceso restringido',
        description: 'No tiene autorización para realizar esta acción',
        variant: 'destructive',
      });
      return;
    }
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (
        file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
        file.type === 'application/vnd.ms-excel'
      ) {
        onFileUpload(file);
      } else {
        toast({
          title: 'Archivo no válido',
          description: 'Por favor, sube un archivo de Excel (.xlsx o .xls).',
          variant: 'destructive',
        });
      }
    }
    // Reset file input to allow uploading the same file again
    if(event.target) {
      event.target.value = '';
    }
  };

  return (
    <>
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        className="hidden"
        accept=".xlsx, .xls"
      />
      <Button onClick={handleButtonClick} disabled={isLoading} variant="outline">
        <Upload className="h-4 w-4 mr-2" />
        {isLoading ? 'Procesando...' : 'Cargar Excel'}
      </Button>
    </>
  );
};

export default InvoiceExcelUpload;
