import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Filter, Download } from "lucide-react";
import InvoiceList from "@/components/InvoiceList";
import InvoiceSummaryCards from "./InvoiceSummaryCards";
import { useExcelExport } from "@/hooks/useExcelExport";

interface AttachedFile {
  id: string;
  name: string;
  size: number;
  type: string;
  url?: string;
  storagePath?: string;
  isUploaded?: boolean;
}

interface Invoice {
  id: string;
  providerName: string;
  amount: number;
  issueDate: string;
  items: Array<{
    description: string;
    quantity: number;
    price: number;
  }>;
  custodio?: string;
  custodiaContabilidad?: boolean;
  recibidoContabilidad?: boolean;
  recibidoCCR?: boolean;
  fechaCustodiaContabilidad?: string;
  fechaRecibidoContabilidad?: string;
  fechaRecibidoCCR?: string;
  // Campos necesarios para la exportación
  invoiceNumber?: string;
  nitProveedor?: string;
  receptionDate: string;
  cufeCude?: string;
  observations?: string;
  attachedFiles?: AttachedFile[];
}

interface InvoiceListCardProps {
  invoices: Invoice[];
  filteredInvoices: Invoice[];
  invoiceStatusFilter: string;
  onStatusFilterChange: (value: string) => void;
  onCreateInvoice: () => void;
  onViewInvoice: (invoiceId: string) => void;
  onDeleteInvoice: (invoiceId: string) => void;
  onBulkDeleteInvoices?: (invoiceIds: string[]) => void;
  onUpdateInvoiceStatus?: (invoiceId: string, field: string, value: boolean) => void;
  hideCreateButton?: boolean;
  showTotal?: boolean;
  showCCR?: boolean;
  showContabilidad?: boolean;
}

const InvoiceListCard = ({ 
  invoices, 
  filteredInvoices, 
  invoiceStatusFilter, 
  onStatusFilterChange, 
  onCreateInvoice, 
  onViewInvoice, 
  onDeleteInvoice,
  onBulkDeleteInvoices,
  onUpdateInvoiceStatus,
  hideCreateButton = false,
  showTotal = true,
  showCCR = true,
  showContabilidad = true
}: InvoiceListCardProps) => {
  // Total de facturas filtradas en la vista actual
  const totalInvoices = filteredInvoices.length;
  
  // Facturas Nuevas: facturas que están en CCR (recibidoCCR = true)
  const newInvoices = invoices.filter(invoice => invoice.recibidoCCR).length;
  
  // Facturas Creadas: facturas que están en Contabilidad (custodiaContabilidad = true)  
  const createdInvoices = invoices.filter(invoice => invoice.custodiaContabilidad).length;
  
  const { exportToExcel, isExporting } = useExcelExport();

  const handleExportExcel = () => {
    // Mapear las facturas al formato esperado por el hook
    const mappedInvoices = filteredInvoices.map(invoice => ({
      id: invoice.id,
      invoiceNumber: invoice.invoiceNumber || invoice.id,
      providerName: invoice.providerName,
      nitProveedor: invoice.nitProveedor,
      receptionDate: invoice.receptionDate || invoice.issueDate,
      amount: invoice.amount,
      cufeCude: invoice.cufeCude,
      custodio: invoice.custodio,
      custodiaContabilidad: invoice.custodiaContabilidad,
      recibidoContabilidad: invoice.recibidoContabilidad,
      recibidoCCR: invoice.recibidoCCR,
      fechaCustodiaContabilidad: invoice.fechaCustodiaContabilidad,
      fechaRecibidoContabilidad: invoice.fechaRecibidoContabilidad,
      fechaRecibidoCCR: invoice.fechaRecibidoCCR,
      observations: invoice.observations
    }));
    
    exportToExcel(mappedInvoices);
  };

  return (
    <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
      <CardHeader>
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <CardTitle className="text-slate-900 text-lg sm:text-2xl">Facturas Tauroquímica</CardTitle>
            <CardDescription className="text-xs sm:text-sm">
              Visualiza y gestiona todas las facturas electrónicas
            </CardDescription>
          </div>
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full sm:w-auto">
            <Button 
              onClick={handleExportExcel}
              disabled={isExporting || filteredInvoices.length === 0}
              variant="outline"
              size="sm"
              className="border-green-200 text-green-600 hover:bg-green-50 w-full sm:w-auto"
            >
              <Download className="h-4 w-4 mr-2" />
              {isExporting ? 'Exportando...' : 'Exportar Excel'}
            </Button>
            {!hideCreateButton && (
              <Button 
                onClick={() => {
                  // Bloquear creación para usuarios CCR y contabilidad
                  try {
                    const email = localStorage.getItem('sb-email') || '';
                    if (email === 'ccr@tauroquimica.co' || email === 'contabilidad@tauroquimica.co') {
                      // Fallback simple si este botón se usa en otra vista
                      // El botón principal ya está controlado en Index.tsx
                      return;
                    }
                  } catch {}
                  onCreateInvoice();
                }}
                size="sm"
                className="bg-blue-600 hover:bg-blue-700 text-white w-full sm:w-auto"
              >
                <Plus className="h-4 w-4 mr-2" />
                Nueva Factura
              </Button>
            )}
          </div>
        </div>
        
        <InvoiceSummaryCards
          totalInvoices={totalInvoices}
          newInvoices={newInvoices}
          createdInvoices={createdInvoices}
          showTotal={showTotal}
          showCCR={showCCR}
          showContabilidad={showContabilidad}
        />
      </CardHeader>
      <CardContent>
        <InvoiceList 
          invoices={filteredInvoices} 
          onViewInvoice={onViewInvoice}
          onDeleteInvoice={onDeleteInvoice}
          onBulkDeleteInvoices={onBulkDeleteInvoices}
          onUpdateInvoiceStatus={onUpdateInvoiceStatus}
        />
      </CardContent>
    </Card>
  );
};

export default InvoiceListCard;
