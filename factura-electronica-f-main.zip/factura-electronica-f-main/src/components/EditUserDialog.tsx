
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { Edit } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuditLog } from "@/hooks/useAuditLog";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

interface User {
  id: string;
  username: string;
  role: string;
  is_active: boolean;
  created_at: string;
}

interface EditUserDialogProps {
  user: User;
  onUserUpdated: () => void;
}

const EditUserDialog = ({ user, onUserUpdated }: EditUserDialogProps) => {
  const [username, setUsername] = useState(user.username || "");
  const [email, setEmail] = useState<string>("");
  const [role, setRole] = useState(user.role);
  const [isActive, setIsActive] = useState(user.is_active);
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const { logAudit } = useAuditLog();

  const isAdminUser = user.role === "Admin";

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      // Validaciones
      if (!isAdminUser && username.length < 3) {
        toast({
          title: "Error de validación",
          description: "El usuario debe tener al menos 3 caracteres",
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }

      if (password && password.length < 6) {
        toast({
          title: "Error de validación",
          description: "La contraseña debe tener al menos 6 caracteres",
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }

      if (password && password !== confirmPassword) {
        toast({
          title: "Error de validación",
          description: "Las contraseñas no coinciden",
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }

      // Invocar función edge para actualizar usuario (auth + perfil)
      const payload: any = {
        user_id: user.id,
        username: isAdminUser ? user.username : username,
        role,
        is_active: isActive,
      };
      if (email) payload.email = email;
      if (password) payload.password = password;

      const { data, error } = await supabase.functions.invoke('admin-update-user', {
        body: payload,
      });

      if (error) {
        toast({
          title: "Error al actualizar usuario",
          description: error.message || 'No fue posible actualizar el usuario',
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }

      toast({
        title: "Usuario actualizado",
        description: `El usuario ${username} ha sido actualizado exitosamente`,
      });
      
      await logAudit({
        action: 'update_user',
        entityType: 'user',
        entityId: user.id,
        details: { username, role, isActive }
      });

      // Limpiar formulario y cerrar modal
      setPassword("");
      setConfirmPassword("");
      setIsLoading(false);
      setOpen(false);
      
      onUserUpdated();
    } catch (err) {
      toast({
        title: "Error al actualizar usuario",
        description: "Ha ocurrido un error inesperado",
        variant: "destructive",
      });
      setIsLoading(false);
    }
  };

  const handleOpenChange = (newOpen: boolean) => {
    setOpen(newOpen);
    if (!newOpen) {
      // Resetear formulario al cerrar
      setUsername(user.username || "");
      setEmail("");
      setRole(user.role);
      setIsActive(user.is_active);
      setPassword("");
      setConfirmPassword("");
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="text-blue-600 hover:bg-blue-50">
          <Edit className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>
            {isAdminUser ? "Cambiar Contraseña del Administrador" : "Editar Usuario"}
          </DialogTitle>
          <DialogDescription>
            {isAdminUser 
              ? "Ingresa la nueva contraseña para el usuario administrador."
              : "Modifica los datos del usuario. Deja la contraseña vacía si no quieres cambiarla."
            }
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            {!isAdminUser && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="edit-username" className="text-slate-700">
                    Usuario
                  </Label>
                  <Input
                    id="edit-username"
                    type="text"
                    placeholder="Nombre de usuario"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                    minLength={3}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-email" className="text-slate-700">
                    Correo Electrónico (opcional)
                  </Label>
                  <Input
                    id="edit-email"
                    type="email"
                    placeholder="Nuevo correo electrónico"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
              </>
            )}
            
            <div className="space-y-2">
              <Label htmlFor="edit-role" className="text-slate-700">
                Rol
              </Label>
              <Select value={role} onValueChange={setRole}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecciona un rol" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="user">Usuario</SelectItem>
                  <SelectItem value="Admin">Administrador</SelectItem>
                  <SelectItem value="Contabilidad">Contabilidad</SelectItem>
                  <SelectItem value="CCR">CCR</SelectItem>
                  <SelectItem value="Recepción">Recepción</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="edit-active"
                checked={isActive}
                onCheckedChange={setIsActive}
              />
              <Label htmlFor="edit-active" className="text-slate-700">
                Usuario activo
              </Label>
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-password" className="text-slate-700">
                Nueva Contraseña (opcional)
              </Label>
              <Input
                id="edit-password"
                type="password"
                placeholder="Dejar vacío para mantener la actual"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                minLength={6}
              />
            </div>
            {password && (
              <div className="space-y-2">
                <Label htmlFor="edit-confirm-password" className="text-slate-700">
                  Confirmar Nueva Contraseña
                </Label>
                <Input
                  id="edit-confirm-password"
                  type="password"
                  placeholder="Confirma la nueva contraseña"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                  minLength={6}
                />
              </div>
            )}
          </div>
          <DialogFooter>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Guardando..." : "Guardar Cambios"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default EditUserDialog;
