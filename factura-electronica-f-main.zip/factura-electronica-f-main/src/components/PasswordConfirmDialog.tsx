
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";

interface PasswordConfirmDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  description: string;
}

const PasswordConfirmDialog = ({
  isOpen,
  onClose,
  onConfirm,
  title,
  description,
}: PasswordConfirmDialogProps) => {
  const [password, setPassword] = useState("");
  const { toast } = useToast();

  const handleConfirm = () => {
    if (password === "T4ur0ns14*") {
      onConfirm();
      onClose();
      setPassword("");
      toast({
        title: "Acción confirmada",
        description: "La verificación ha sido removida exitosamente",
      });
    } else {
      toast({
        title: "Contraseña incorrecta",
        description: "La contraseña ingresada no es válida",
        variant: "destructive",
      });
    }
  };

  const handleClose = () => {
    setPassword("");
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>
        
        <div className="space-y-2">
          <label htmlFor="password" className="text-sm font-medium">
            Ingresa la contraseña para confirmar:
          </label>
          <Input
            id="password"
            type="password"
            placeholder="Contraseña"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="border-gray-200"
          />
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleClose}>
            Cancelar
          </Button>
          <Button
            onClick={handleConfirm}
            className="bg-red-600 hover:bg-red-700 text-white"
          >
            Confirmar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default PasswordConfirmDialog;
