
import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Users, UserPlus, Trash2, ArrowLeft, UserCheck, UserX } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import EditUserDialog from "./EditUserDialog";
import { useAuditLog } from "@/hooks/useAuditLog";

interface User {
  id: string;
  username: string;
  role: string;
  is_active: boolean;
  created_at: string;
}

interface UserManagementProps {
  onBack: () => void;
  onCreateUser: () => void;
  onViewLogs?: () => void;
}

const UserManagement = ({ onBack, onCreateUser, onViewLogs }: UserManagementProps) => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const { logAudit } = useAuditLog();

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) {
        console.error("Error loading users:", error);
        toast({
          title: "Error al cargar usuarios",
          description: error.message,
          variant: "destructive",
        });
      } else {
        console.log("Users loaded:", data);
        setUsers(data || []);
      }
    } catch (err) {
      toast({
        title: "Error al cargar usuarios",
        description: "No se pudieron cargar los usuarios",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const deleteUser = async (userId: string, username: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('admin-delete-user', {
        body: { user_id: userId },
      });
      if (error) {
        toast({
          title: "Error al eliminar usuario",
          description: error.message || 'No se pudo eliminar el usuario',
          variant: "destructive",
        });
      } else {
        toast({
          title: "Usuario eliminado",
          description: `El usuario ${username} ha sido eliminado`,
        });
        await logAudit({
          action: 'delete_user',
          entityType: 'user',
          entityId: userId,
          details: { username }
        });
        loadUsers();
      }
    } catch (err: any) {
      toast({
        title: "Error al eliminar usuario",
        description: err.message || "No se pudo eliminar el usuario",
        variant: "destructive",
      });
    }
  };

  const toggleUserStatus = async (userId: string, username: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ is_active: !currentStatus })
        .eq('id', userId);
      
      if (error) {
        toast({
          title: "Error al actualizar estado",
          description: error.message,
          variant: "destructive",
        });
      } else {
        toast({
          title: currentStatus ? "Usuario inactivado" : "Usuario activado",
          description: `El usuario ${username} ha sido ${currentStatus ? 'inactivado' : 'activado'}`,
        });
        loadUsers();
      }
    } catch (err: any) {
      toast({
        title: "Error al actualizar estado",
        description: err.message || "No se pudo actualizar el estado del usuario",
        variant: "destructive",
      });
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('es-ES');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl border-0 shadow-xl bg-white/80 backdrop-blur-sm">
        <CardHeader className="text-center space-y-4">
          <div className="mx-auto w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center">
            <Users className="h-8 w-8 text-white" />
          </div>
          <CardTitle className="text-2xl text-slate-900">
            Gestión de Usuarios
          </CardTitle>
          <CardDescription>
            Administra los usuarios del sistema
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Button 
              onClick={onBack}
              variant="outline"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Volver al Login
            </Button>
            {onViewLogs && (
              <Button 
                onClick={onViewLogs}
                variant="outline"
                className="flex-1"
              >
                Ver Registro de Auditoría
              </Button>
            )}
            <Button 
              onClick={onCreateUser}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              <UserPlus className="h-4 w-4 mr-2" />
              Crear Usuario
            </Button>
          </div>

          <div className="space-y-2">
            <h3 className="text-lg font-semibold text-slate-900">Usuarios Registrados</h3>
            {loading ? (
              <div className="text-center py-8 text-slate-600">
                <Users className="h-12 w-12 mx-auto mb-4 text-slate-400 animate-pulse" />
                <p>Cargando usuarios...</p>
              </div>
            ) : users.length === 0 ? (
              <div className="text-center py-8 text-slate-600">
                <Users className="h-12 w-12 mx-auto mb-4 text-slate-400" />
                <p>No hay usuarios registrados</p>
                <p className="text-sm">Crea el primer usuario para comenzar</p>
              </div>
            ) : (
              <div className="space-y-2">
                {users.map((user) => (
                  <div key={user.id} className="flex items-center justify-between p-3 bg-white rounded-lg border">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <p className="font-medium text-slate-900">
                          {user.username || 'Sin nombre'}
                        </p>
                        <Badge variant={user.role === 'Admin' ? 'default' : 'secondary'}>
                          {user.role === 'Admin' ? 'Administrador' : 
                           user.role === 'Contabilidad' ? 'Contabilidad' :
                           user.role === 'CCR' ? 'CCR' : 'Usuario'}
                        </Badge>
                        {!user.is_active && (
                          <Badge variant="destructive">Inactivo</Badge>
                        )}
                      </div>
                      <p className="text-sm text-slate-600">
                        Creado: {formatDate(user.created_at)}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <EditUserDialog 
                        user={user} 
                        onUserUpdated={loadUsers}
                      />
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => toggleUserStatus(user.id, user.username, user.is_active)}
                        className={user.is_active ? "text-orange-600 hover:bg-orange-50" : "text-green-600 hover:bg-green-50"}
                      >
                        {user.is_active ? (
                          <UserX className="h-4 w-4" />
                        ) : (
                          <UserCheck className="h-4 w-4" />
                        )}
                      </Button>
                      {user.role !== "Admin" && (
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="outline" size="sm" className="text-red-600 hover:bg-red-50">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>¿Eliminar usuario?</AlertDialogTitle>
                              <AlertDialogDescription>
                                Esta acción no se puede deshacer. El usuario "{user.username}" será eliminado permanentemente.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancelar</AlertDialogCancel>
                              <AlertDialogAction 
                                onClick={() => deleteUser(user.id, user.username)}
                                className="bg-red-600 hover:bg-red-700"
                              >
                                Eliminar
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default UserManagement;
