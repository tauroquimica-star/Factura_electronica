import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import InvoiceNumberSection from "./invoice/InvoiceNumberSection";
import ProviderInfoSection from "./invoice/ProviderInfoSection";
import DatesSection from "./invoice/DatesSection";
import AdditionalInfoSection from "./invoice/AdditionalInfoSection";
import InvoiceItemsSection from "./invoice/InvoiceItemsSection";
import ObservationsSection from "./invoice/ObservationsSection";
import StatusCheckboxSection from "./invoice/StatusCheckboxSection";
import AttachedFilesSection from "./invoice/AttachedFilesSection";

interface InvoiceItem {
  description: string;
  quantity: number;
  price: number;
}

interface AttachedFile {
  id: string;
  name: string;
  size: number;
  type: string;
  url?: string;
  file?: File;
}

interface CreateInvoiceFormProps {
  onSubmit: (invoice: any) => void;
  editingInvoice?: any;
  isEditing?: boolean;
}

const CreateInvoiceForm = ({ onSubmit, editingInvoice, isEditing = false }: CreateInvoiceFormProps) => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    invoiceNumber: "",
    providerName: "",
    nitProveedor: "",
    issueDate: "",
    receptionDate: "",
    cufeCude: "",
    custodio: "",
    observations: "",
    observationsUser: "",
    observationsDate: "",
    custodiaContabilidad: false,
    recibidoContabilidad: false,
    recibidoCCR: false,
    fechaCustodiaContabilidad: "",
    fechaRecibidoContabilidad: "",
    fechaRecibidoCCR: ""
  });

  const [items, setItems] = useState<InvoiceItem[]>([
    { description: "", quantity: 1, price: 0 }
  ]);

  const [attachedFiles, setAttachedFiles] = useState<AttachedFile[]>([]);

  // Load data if editing
  useEffect(() => {
    if (isEditing && editingInvoice) {
      setFormData({
        invoiceNumber: editingInvoice.invoiceNumber || editingInvoice.id || "",
        providerName: editingInvoice.providerName || "",
        nitProveedor: editingInvoice.nitProveedor || "",
        issueDate: editingInvoice.issueDate || editingInvoice.date || "",
        receptionDate: editingInvoice.receptionDate || editingInvoice.dueDate || "",
        cufeCude: editingInvoice.cufeCude || "",
        custodio: editingInvoice.custodio || "",
        observations: editingInvoice.observations || "",
        observationsUser: editingInvoice.observationsUser || "",
        observationsDate: editingInvoice.observationsDate || "",
        custodiaContabilidad: editingInvoice.custodiaContabilidad || false,
        recibidoContabilidad: editingInvoice.recibidoContabilidad || false,
        recibidoCCR: editingInvoice.recibidoCCR || false,
        fechaCustodiaContabilidad: editingInvoice.fechaCustodiaContabilidad || "",
        fechaRecibidoContabilidad: editingInvoice.fechaRecibidoContabilidad || "",
        fechaRecibidoCCR: editingInvoice.fechaRecibidoCCR || ""
      });
      setItems(editingInvoice.items || [{ description: "", quantity: 1, price: 0 }]);
      setAttachedFiles(editingInvoice.attachedFiles || []);
    }
  }, [isEditing, editingInvoice]);

  const handleFormDataChange = (field: string, value: string) => {
    const updates: any = {
      [field]: value
    };
    
    // Si se está modificando las observaciones, actualizar usuario y fecha
    if (field === 'observations' && value.trim() !== '') {
      const currentUser = localStorage.getItem('currentUser') || 'Usuario';
      updates.observationsUser = currentUser;
      updates.observationsDate = new Date().toISOString();
    }
    
    setFormData(prev => ({
      ...prev,
      ...updates
    }));
  };

  const handleCheckboxChange = (field: string, checked: boolean) => {
    const currentDate = new Date().toISOString();
    setFormData(prev => ({
      ...prev,
      [field]: checked,
      [`fecha${field.charAt(0).toUpperCase() + field.slice(1)}`]: checked ? currentDate : ""
    }));
  };

  const handleItemChange = (index: number, field: keyof InvoiceItem, value: string | number) => {
    setItems(prev => prev.map((item, i) => 
      i === index ? { ...item, [field]: value } : item
    ));
  };

  const addItem = () => {
    setItems(prev => [...prev, { description: "", quantity: 1, price: 0 }]);
  };

  const removeItem = (index: number) => {
    if (items.length > 1) {
      setItems(prev => prev.filter((_, i) => i !== index));
    }
  };

  const handleAttachedFilesChange = (files: AttachedFile[]) => {
    setAttachedFiles(files);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.invoiceNumber || !formData.providerName || !formData.nitProveedor || !formData.issueDate || !formData.receptionDate) {
      toast({
        title: "Error",
        description: "Por favor completa todos los campos obligatorios",
        variant: "destructive"
      });
      return;
    }

    // Allow saving without items - filter items with description and calculate amount
    const validItems = items.filter(item => item.description.trim() !== "");
    const amount = validItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);

    const invoice = {
      ...formData,
      amount,
      items: validItems, // Can be empty array now
      attachedFiles,
      id: editingInvoice?.id
    };

    onSubmit(invoice);
    
    if (!isEditing) {
      // Reset form only if not editing
      setFormData({
        invoiceNumber: "",
        providerName: "",
        nitProveedor: "",
        issueDate: "",
        receptionDate: "",
        cufeCude: "",
        custodio: "",
        observations: "",
        observationsUser: "",
        observationsDate: "",
        custodiaContabilidad: false,
        recibidoContabilidad: false,
        recibidoCCR: false,
        fechaCustodiaContabilidad: "",
        fechaRecibidoContabilidad: "",
        fechaRecibidoCCR: ""
      });
      setItems([{ description: "", quantity: 1, price: 0 }]);
      setAttachedFiles([]);
    }
  };

  const isFieldLocked = (fieldName: string) => {
    return isEditing && (fieldName === 'invoiceNumber' || fieldName === 'receptionDate');
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <InvoiceNumberSection
        invoiceNumber={formData.invoiceNumber}
        onChange={(value) => handleFormDataChange('invoiceNumber', value)}
        isLocked={isFieldLocked('invoiceNumber')}
      />

      <ProviderInfoSection
        providerName={formData.providerName}
        nitProveedor={formData.nitProveedor}
        onProviderNameChange={(value) => handleFormDataChange('providerName', value)}
        onNitChange={(value) => handleFormDataChange('nitProveedor', value)}
      />

      <DatesSection
        issueDate={formData.issueDate}
        receptionDate={formData.receptionDate}
        onIssueDateChange={(value) => handleFormDataChange('issueDate', value)}
        onReceptionDateChange={(value) => handleFormDataChange('receptionDate', value)}
        isReceptionDateLocked={isFieldLocked('receptionDate')}
      />

      <AdditionalInfoSection
        cufeCude={formData.cufeCude}
        custodio={formData.custodio}
        onCufeChange={(value) => handleFormDataChange('cufeCude', value)}
        onCustodioChange={(value) => handleFormDataChange('custodio', value)}
      />

      <StatusCheckboxSection
        custodiaContabilidad={formData.custodiaContabilidad}
        recibidoContabilidad={formData.recibidoContabilidad}
        recibidoCCR={formData.recibidoCCR}
        fechaCustodiaContabilidad={formData.fechaCustodiaContabilidad}
        fechaRecibidoContabilidad={formData.fechaRecibidoContabilidad}
        fechaRecibidoCCR={formData.fechaRecibidoCCR}
        onCustodiaContabilidadChange={(checked) => handleCheckboxChange('custodiaContabilidad', checked)}
        onRecibidoContabilidadChange={(checked) => handleCheckboxChange('recibidoContabilidad', checked)}
        onRecibidoCCRChange={(checked) => handleCheckboxChange('recibidoCCR', checked)}
      />

      <InvoiceItemsSection
        items={items}
        onItemChange={handleItemChange}
        onAddItem={addItem}
        onRemoveItem={removeItem}
      />

      <AttachedFilesSection
        attachedFiles={attachedFiles}
        onFilesChange={handleAttachedFilesChange}
        invoiceId={editingInvoice?.id}
      />

      <ObservationsSection
        observations={formData.observations}
        onChange={(value) => handleFormDataChange('observations', value)}
        observationsUser={formData.observationsUser}
        observationsDate={formData.observationsDate}
      />

      <Separator />

      <div className="flex justify-end">
        <Button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white">
          {isEditing ? "Actualizar Factura" : "Crear Factura"}
        </Button>
      </div>
    </form>
  );
};

export default CreateInvoiceForm;
