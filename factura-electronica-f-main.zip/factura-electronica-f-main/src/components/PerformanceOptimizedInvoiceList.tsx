import { memo, useMemo, useCallback, useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Trash } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { useDebounce } from "@/hooks/useDebounce";
import VirtualizedInvoiceList from "./VirtualizedInvoiceList";
import DeleteInvoiceDialog from "./DeleteInvoiceDialog";
import PasswordConfirmDialog from "./PasswordConfirmDialog";
import BulkDeleteDialog from "./BulkDeleteDialog";

interface AttachedFile {
  id: string;
  name: string;
  size: number;
  type: string;
  url?: string;
  storagePath?: string;
  isUploaded?: boolean;
}

interface Invoice {
  id: string;
  invoiceNumber?: string;
  providerName: string;
  amount: number;
  issueDate: string;
  receptionDate: string;
  cufeCude?: string;
  items: Array<{
    description: string;
    quantity: number;
    price: number;
  }>;
  custodiaContabilidad?: boolean;
  recibidoContabilidad?: boolean;
  recibidoCCR?: boolean;
  fechaCustodiaContabilidad?: string;
  fechaRecibidoContabilidad?: string;
  fechaRecibidoCCR?: string;
  attachedFiles?: AttachedFile[];
}

interface PerformanceOptimizedInvoiceListProps {
  invoices: Invoice[];
  onViewInvoice: (invoiceId: string) => void;
  onDeleteInvoice?: (invoiceId: string) => void;
  onBulkDeleteInvoices?: (invoiceIds: string[]) => void;
  onUpdateInvoiceStatus?: (invoiceId: string, field: string, value: boolean) => void;
}

const PerformanceOptimizedInvoiceList = memo(({
  invoices,
  onViewInvoice,
  onDeleteInvoice,
  onBulkDeleteInvoices,
  onUpdateInvoiceStatus
}: PerformanceOptimizedInvoiceListProps) => {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedInvoices, setSelectedInvoices] = useState<string[]>([]);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [invoiceToDelete, setInvoiceToDelete] = useState<string | null>(null);
  const [passwordDialogOpen, setPasswordDialogOpen] = useState(false);
  const [bulkDeleteDialogOpen, setBulkDeleteDialogOpen] = useState(false);
  const [pendingStatusChange, setPendingStatusChange] = useState<{
    invoiceId: string;
    field: string;
    value: boolean;
    checkboxName: string;
  } | null>(null);

  // Debounce search term to avoid excessive filtering
  const debouncedSearchTerm = useDebounce(searchTerm, 300);

  // Memoize filtered invoices
  const filteredInvoices = useMemo(() => {
    if (!debouncedSearchTerm.trim()) return invoices;
    
    const searchLower = debouncedSearchTerm.toLowerCase();
    return invoices.filter(invoice => {
      const invoiceNumber = invoice.invoiceNumber || invoice.id;
      const cufeCude = invoice.cufeCude || '';
      return invoice.providerName.toLowerCase().includes(searchLower) ||
             invoiceNumber.toLowerCase().includes(searchLower) ||
             cufeCude.toLowerCase().includes(searchLower);
    });
  }, [invoices, debouncedSearchTerm]);

  const handleSelectInvoice = useCallback((invoiceId: string, checked: boolean) => {
    setSelectedInvoices(prev => 
      checked 
        ? [...prev, invoiceId]
        : prev.filter(id => id !== invoiceId)
    );
  }, []);

  const handleSelectAll = useCallback(() => {
    setSelectedInvoices(prev => 
      prev.length === filteredInvoices.length 
        ? [] 
        : filteredInvoices.map(invoice => invoice.id)
    );
  }, [filteredInvoices]);

  const handleBulkDelete = useCallback(() => {
    if (selectedInvoices.length > 0) {
      setBulkDeleteDialogOpen(true);
    }
  }, [selectedInvoices.length]);

  const handleBulkDeleteConfirm = useCallback(() => {
    if (onBulkDeleteInvoices && selectedInvoices.length > 0) {
      onBulkDeleteInvoices(selectedInvoices);
      setSelectedInvoices([]);
    }
    setBulkDeleteDialogOpen(false);
  }, [onBulkDeleteInvoices, selectedInvoices]);

  const handleDeleteClick = useCallback((invoiceId: string) => {
    setInvoiceToDelete(invoiceId);
    setDeleteDialogOpen(true);
  }, []);

  const handleDeleteConfirm = useCallback(() => {
    if (invoiceToDelete && onDeleteInvoice) {
      onDeleteInvoice(invoiceToDelete);
    }
    setInvoiceToDelete(null);
    setDeleteDialogOpen(false);
  }, [invoiceToDelete, onDeleteInvoice]);

  const getCheckboxName = useCallback((field: string) => {
    const names: { [key: string]: string } = {
      'custodiaContabilidad': 'Custodia de Contabilidad',
      'recibidoContabilidad': 'Recibido por Contabilidad',
      'recibidoCCR': 'Recibido por CCR'
    };
    return names[field] || field;
  }, []);

  const handleCheckboxChange = useCallback((invoiceId: string, field: string, checked: boolean) => {
    if (!onUpdateInvoiceStatus) return;

    // Verificar autorización para usuarios de recepción
    if (user?.email === "recepcion@tauroquimica.co") {
      const restrictedFields = ['custodiaContabilidad', 'recibidoContabilidad', 'recibidoCCR'];
      if (restrictedFields.includes(field)) {
        toast({
          title: "Acceso restringido",
          description: "No tiene autorización para realizar esta verificación",
          variant: "destructive",
        });
        return;
      }
    }

    // Verificar autorización para usuarios de CCR
    if (user?.email === "ccr@tauroquimica.co") {
      const restrictedFields = ['custodiaContabilidad', 'recibidoContabilidad'];
      if (restrictedFields.includes(field)) {
        toast({
          title: "Acceso restringido",
          description: "No tiene autorización para realizar esta verificación",
          variant: "destructive",
        });
        return;
      }
    }

    // Verificar autorización para usuarios de contabilidad
    if (user?.email === "contabilidad@tauroquimica.co") {
      const restrictedFields = ['recibidoCCR'];
      if (restrictedFields.includes(field)) {
        toast({
          title: "Acceso restringido",
          description: "No tiene autorización para realizar esta verificación",
          variant: "destructive",
        });
        return;
      }
    }

    const currentValue = invoices.find(inv => inv.id === invoiceId)?.[field as keyof Invoice] as boolean;
    
    // Si está marcado y se quiere desmarcar, pedir contraseña
    if (currentValue && !checked) {
      setPendingStatusChange({
        invoiceId,
        field,
        value: checked,
        checkboxName: getCheckboxName(field)
      });
      setPasswordDialogOpen(true);
    } else {
      // Si no está marcado, permitir marcar sin contraseña
      onUpdateInvoiceStatus(invoiceId, field, checked);
    }
  }, [invoices, onUpdateInvoiceStatus, getCheckboxName, user, toast]);

  const handlePasswordConfirm = useCallback(() => {
    if (pendingStatusChange && onUpdateInvoiceStatus) {
      onUpdateInvoiceStatus(
        pendingStatusChange.invoiceId,
        pendingStatusChange.field,
        pendingStatusChange.value
      );
    }
    setPendingStatusChange(null);
    setPasswordDialogOpen(false);
  }, [pendingStatusChange, onUpdateInvoiceStatus]);

  const handlePasswordCancel = useCallback(() => {
    setPasswordDialogOpen(false);
    setPendingStatusChange(null);
  }, []);

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            placeholder="Buscar por proveedor, número de factura o CUFE/CUDE..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-white border-gray-200"
          />
        </div>
        {selectedInvoices.length > 0 && (
          <Button
            onClick={handleBulkDelete}
            variant="outline"
            className="border-red-200 text-red-600 hover:bg-red-50"
          >
            <Trash className="h-4 w-4 mr-2" />
            Eliminar Seleccionadas ({selectedInvoices.length})
          </Button>
        )}
      </div>

      {filteredInvoices.length > 0 ? (
        <VirtualizedInvoiceList
          invoices={filteredInvoices}
          selectedInvoices={selectedInvoices}
          onSelectInvoice={handleSelectInvoice}
          onViewInvoice={onViewInvoice}
          onDeleteInvoice={handleDeleteClick}
          onCheckboxChange={handleCheckboxChange}
        />
      ) : (
        <div className="text-center py-8">
          <p className="text-slate-500">No se encontraron facturas que coincidan con los filtros.</p>
        </div>
      )}

      <DeleteInvoiceDialog
        isOpen={deleteDialogOpen}
        onClose={() => setDeleteDialogOpen(false)}
        onConfirm={handleDeleteConfirm}
        invoiceId={invoiceToDelete || ""}
      />

      <BulkDeleteDialog
        isOpen={bulkDeleteDialogOpen}
        onClose={() => setBulkDeleteDialogOpen(false)}
        onConfirm={handleBulkDeleteConfirm}
        selectedCount={selectedInvoices.length}
      />

      <PasswordConfirmDialog
        isOpen={passwordDialogOpen}
        onClose={handlePasswordCancel}
        onConfirm={handlePasswordConfirm}
        title="Confirmar acción"
        description={
          pendingStatusChange 
            ? `¿Estás seguro que deseas remover la verificación de "${pendingStatusChange.checkboxName}"?`
            : ""
        }
      />
    </div>
  );
});

PerformanceOptimizedInvoiceList.displayName = 'PerformanceOptimizedInvoiceList';

export default PerformanceOptimizedInvoiceList;