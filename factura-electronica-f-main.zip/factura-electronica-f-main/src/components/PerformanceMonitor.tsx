
import { useEffect } from 'react';

interface PerformanceMonitorProps {
  enabled?: boolean;
}

const PerformanceMonitor = ({ enabled = process.env.NODE_ENV === 'development' }: PerformanceMonitorProps) => {
  useEffect(() => {
    if (!enabled) return;

    const observer = new PerformanceObserver((list) => {
      list.getEntries().forEach((entry) => {
        if (entry.entryType === 'measure') {
          console.log(`Performance: ${entry.name} took ${entry.duration.toFixed(2)}ms`);
        }
        
        if (entry.entryType === 'navigation') {
          const nav = entry as PerformanceNavigationTiming;
          console.log('Navigation Performance:', {
            'DOM Content Loaded': nav.domContentLoadedEventEnd - nav.domContentLoadedEventStart,
            'Load Complete': nav.loadEventEnd - nav.loadEventStart,
            'DOM Complete': nav.domComplete - nav.fetchStart,
          });
        }

        // Monitor Core Web Vitals
        if (entry.entryType === 'largest-contentful-paint') {
          console.log('LCP:', entry.startTime);
        }
        
        if (entry.entryType === 'first-input') {
          const fidEntry = entry as PerformanceEventTiming;
          console.log('FID:', fidEntry.processingStart - fidEntry.startTime);
        }
      });
    });

    observer.observe({ entryTypes: ['measure', 'navigation', 'largest-contentful-paint', 'first-input'] });

    // Monitor memory usage (if available)
    const checkMemory = () => {
      if ('memory' in performance) {
        const memory = (performance as any).memory;
        console.log('Memory Usage:', {
          used: `${(memory.usedJSHeapSize / 1048576).toFixed(2)} MB`,
          total: `${(memory.totalJSHeapSize / 1048576).toFixed(2)} MB`,
          limit: `${(memory.jsHeapSizeLimit / 1048576).toFixed(2)} MB`
        });
      }
    };

    const memoryInterval = setInterval(checkMemory, 30000);

    return () => {
      observer.disconnect();
      clearInterval(memoryInterval);
    };
  }, [enabled]);

  return null;
};

export default PerformanceMonitor;
