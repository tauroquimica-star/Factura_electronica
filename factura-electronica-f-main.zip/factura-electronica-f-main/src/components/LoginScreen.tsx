
import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Lock, User, Settings, Mail, Users } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import UserRegistration from "./UserRegistration";
import UserManagement from "./UserManagement";
import { useAuditLog } from "@/hooks/useAuditLog";

interface LoginScreenProps {
  onLogin: () => void;
}

const LoginScreen = ({ onLogin }: LoginScreenProps) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [currentView, setCurrentView] = useState<"login" | "register" | "manage">("login");
  const [currentUser, setCurrentUser] = useState<any>(null);
  const { toast } = useToast();
  const { signIn, getCurrentUserProfile } = useAuth();
  const { logAudit } = useAuditLog();

  useEffect(() => {
    // Verificar si hay un usuario autenticado y cargar su perfil
    const checkCurrentUser = async () => {
      const res = await getCurrentUserProfile();
      const profile = (res as any)?.data ?? null;
      if (profile) {
        setCurrentUser(profile);
      }
    };
    checkCurrentUser();
  }, [getCurrentUserProfile]);

  const checkIfUserIsAdmin = async () => {
    const res = await getCurrentUserProfile();
    const profile = (res as any)?.data ?? null;
    if (profile) {
      setCurrentUser(profile);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Verificar usuario Admin por defecto usando email admin@test.com
    if (email === "admin@test.com" && password === "123") {
      try {
        const { data, error } = await signIn(email, password);
        if (error) {
          toast({
            title: "Error de autenticación",
            description: error.message,
            variant: "destructive",
          });
        } else {
          await checkIfUserIsAdmin();
          const resProfile = await getCurrentUserProfile();
          const profileData = (resProfile as any)?.data ?? null;
          
          // Verificar si el usuario está activo
          if (profileData && !profileData.is_active) {
            // Cerrar sesión si el usuario está inactivo
            await supabase.auth.signOut();
            toast({
              title: "Usuario inactivo",
              description: "Tu cuenta ha sido desactivada. Contacta al administrador.",
              variant: "destructive",
            });
            setIsLoading(false);
            return;
          }
          
          if (profileData?.username) {
            localStorage.setItem("currentUser", profileData.username);
          } else {
            localStorage.setItem("currentUser", email);
          }
          toast({
            title: "Inicio de sesión exitoso",
            description: "Bienvenido al sistema de gestión de facturas",
          });
          await logAudit({
            action: 'login',
            entityType: 'auth',
            details: { email }
          });
          onLogin();
        }
      } catch (err) {
        toast({
          title: "Error de autenticación",
          description: "Email o contraseña incorrectos",
          variant: "destructive",
        });
      }
    } else {
      // Intentar login con Supabase
      try {
        const { data, error } = await signIn(email, password);
        if (error) {
          toast({
            title: "Error de autenticación",
            description: error.message,
            variant: "destructive",
          });
        } else {
          const res = await getCurrentUserProfile();
          const profile = (res as any)?.data ?? null;
          
          // Verificar si el usuario está activo
          if (profile && !profile.is_active) {
            // Cerrar sesión si el usuario está inactivo
            await supabase.auth.signOut();
            toast({
              title: "Usuario inactivo",
              description: "Tu cuenta ha sido desactivada. Contacta al administrador.",
              variant: "destructive",
            });
            setIsLoading(false);
            return;
          }
          
          if (profile) {
            setCurrentUser(profile);
          }
          if (profile?.username) {
            localStorage.setItem("currentUser", profile.username);
          } else {
            localStorage.setItem("currentUser", email);
          }
          toast({
            title: "Inicio de sesión exitoso",
            description: `Bienvenido ${profile?.username || email}`,
          });
          await logAudit({
            action: 'login',
            entityType: 'auth',
            details: { email, username: profile?.username }
          });
          onLogin();
        }
      } catch (err) {
        toast({
          title: "Error de autenticación",
          description: "Email o contraseña incorrectos",
          variant: "destructive",
        });
      }
    }

    setIsLoading(false);
  };

  if (currentView === "register") {
    return (
      <UserRegistration 
        onBack={() => setCurrentView("login")}
        onUserCreated={() => setCurrentView("login")}
      />
    );
  }

  if (currentView === "manage") {
    return (
      <UserManagement
        onBack={() => setCurrentView("login")}
        onCreateUser={() => setCurrentView("register")}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md border-0 shadow-xl bg-white/80 backdrop-blur-sm">
        <CardHeader className="text-center space-y-4">
          <div className="mx-auto w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center">
            <img 
              src="/lovable-uploads/f119bf5e-6036-403a-a891-54806515a139.png" 
              alt="Sistema de Facturas" 
              className="h-8 w-8 object-contain"
            />
          </div>
          <CardTitle className="text-2xl text-slate-900">
            Sistema de Facturas
          </CardTitle>
          <CardDescription>
            Ingresa tus credenciales para acceder al sistema
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-slate-700">
                Email
              </Label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                <Input
                  id="email"
                  type="email"
                  placeholder="Ingresa tu email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10"
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="text-slate-700">
                Contraseña
              </Label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                <Input
                  id="password"
                  type="password"
                  placeholder="Ingresa tu contraseña"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <Button 
              type="submit" 
              className="w-full bg-blue-600 hover:bg-blue-700 text-white"
              disabled={isLoading}
            >
              {isLoading ? "Iniciando sesión..." : "Iniciar Sesión"}
            </Button>
          </form>

        </CardContent>
      </Card>
    </div>
  );
};

export default LoginScreen;
