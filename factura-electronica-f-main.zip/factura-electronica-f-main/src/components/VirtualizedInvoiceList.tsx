
import { memo, useMemo, useCallback, useRef, useEffect, useState } from "react";
import { Checkbox } from "@/components/ui/checkbox";
import { Paperclip } from "lucide-react";
import InvoiceStatusManager from "./invoice/InvoiceStatusManager";
import InvoiceActions from "./invoice/InvoiceActions";

interface AttachedFile {
  id: string;
  name: string;
  size: number;
  type: string;
  url?: string;
  storagePath?: string;
  isUploaded?: boolean;
}

interface Invoice {
  id: string;
  invoiceNumber?: string;
  providerName: string;
  amount: number;
  issueDate: string;
  receptionDate: string;
  items: Array<{
    description: string;
    quantity: number;
    price: number;
  }>;
  custodiaContabilidad?: boolean;
  recibidoContabilidad?: boolean;
  recibidoCCR?: boolean;
  fechaCustodiaContabilidad?: string;
  fechaRecibidoContabilidad?: string;
  fechaRecibidoCCR?: string;
  attachedFiles?: AttachedFile[];
}

interface VirtualizedInvoiceListProps {
  invoices: Invoice[];
  selectedInvoices: string[];
  onSelectInvoice: (invoiceId: string, checked: boolean) => void;
  onViewInvoice: (invoiceId: string) => void;
  onDeleteInvoice?: (invoiceId: string) => void;
  onUpdateInvoiceStatus?: (invoiceId: string, field: string, value: boolean) => void;
  onCheckboxChange: (invoiceId: string, field: string, checked: boolean) => void;
}

const ITEM_HEIGHT = 200;
const BUFFER_SIZE = 3; // Reduced buffer size for better performance

const VirtualizedInvoiceList = memo(({
  invoices,
  selectedInvoices,
  onSelectInvoice,
  onViewInvoice,
  onDeleteInvoice,
  onCheckboxChange
}: VirtualizedInvoiceListProps) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [scrollTop, setScrollTop] = useState(0);
  const [containerHeight, setContainerHeight] = useState(600);

  const handleScroll = useCallback((e: React.UIEvent<HTMLDivElement>) => {
    setScrollTop(e.currentTarget.scrollTop);
  }, []);

  const formatDateTime = useCallback((dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
  }, []);

  const getProcessingSteps = useCallback((invoice: Invoice) => {
    return [
      {
        name: "Custodia Contabilidad",
        field: "custodiaContabilidad",
        completed: invoice.custodiaContabilidad,
        date: invoice.fechaCustodiaContabilidad
      },
      {
        name: "Recibido Contabilidad", 
        field: "recibidoContabilidad",
        completed: invoice.recibidoContabilidad,
        date: invoice.fechaRecibidoContabilidad
      },
      {
        name: "Recibido CCR",
        field: "recibidoCCR",
        completed: invoice.recibidoCCR,
        date: invoice.fechaRecibidoCCR
      }
    ];
  }, []);

  const visibleItems = useMemo(() => {
    const startIndex = Math.max(0, Math.floor(scrollTop / ITEM_HEIGHT) - BUFFER_SIZE);
    const endIndex = Math.min(
      invoices.length - 1,
      Math.floor((scrollTop + containerHeight) / ITEM_HEIGHT) + BUFFER_SIZE
    );

    return {
      startIndex,
      endIndex,
      items: invoices.slice(startIndex, endIndex + 1)
    };
  }, [invoices, scrollTop, containerHeight]);

  useEffect(() => {
    const updateHeight = () => {
      if (containerRef.current) {
        setContainerHeight(containerRef.current.clientHeight);
      }
    };

    updateHeight();
    window.addEventListener('resize', updateHeight);
    return () => window.removeEventListener('resize', updateHeight);
  }, []);

  const totalHeight = invoices.length * ITEM_HEIGHT;

  return (
    <div 
      ref={containerRef}
      className="relative overflow-auto"
      style={{ height: '600px' }}
      onScroll={handleScroll}
    >
      <div style={{ height: totalHeight, position: 'relative' }}>
        <div 
          style={{ 
            transform: `translateY(${visibleItems.startIndex * ITEM_HEIGHT}px)`,
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0
          }}
        >
          {visibleItems.items.map((invoice, index) => {
            const displayInvoiceNumber = invoice.invoiceNumber || invoice.id;
            const isSelected = selectedInvoices.includes(invoice.id);
            
            return (
              <div
                key={invoice.id}
                className={`bg-white rounded-lg border p-4 mb-3 hover:shadow-md transition-all duration-200 ${
                  isSelected ? 'border-blue-300 bg-blue-50' : 'border-gray-200'
                }`}
                style={{ height: ITEM_HEIGHT - 12 }}
              >
                <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-4 h-full">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <Checkbox
                        checked={isSelected}
                        onCheckedChange={(checked) => onSelectInvoice(invoice.id, checked as boolean)}
                        className="h-4 w-4"
                      />
                      <h3 className="font-semibold text-slate-900">{displayInvoiceNumber}</h3>
                      {invoice.attachedFiles && invoice.attachedFiles.length > 0 && (
                        <div className="flex items-center gap-1 text-slate-500" title={`${invoice.attachedFiles.length} archivo(s) adjunto(s)`}>
                          <Paperclip className="h-4 w-4" />
                          <span className="text-xs font-medium">{invoice.attachedFiles.length}</span>
                        </div>
                      )}
                    </div>
                    <p className="text-slate-600 font-medium">{invoice.providerName}</p>
                    <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 text-sm text-slate-500 mt-1">
                      <span>Fecha Recepción: {new Date(invoice.receptionDate.replace(/-/g, '\/')).toLocaleDateString()}</span>
                    </div>
                  </div>
                  
                  <div className="flex flex-col lg:flex-row items-start lg:items-center gap-4">
                    <div className="flex-1 lg:min-w-[300px]">
                      <div className="space-y-2">
                        {getProcessingSteps(invoice).map((step, stepIndex) => (
                          <InvoiceStatusManager
                            key={stepIndex}
                            invoiceId={invoice.id}
                            field={step.field}
                            checked={step.completed || false}
                            label={step.name}
                            date={step.date}
                            onCheckboxChange={onCheckboxChange}
                            formatDateTime={formatDateTime}
                          />
                        ))}
                      </div>
                    </div>
                    
                    <InvoiceActions
                      invoiceId={invoice.id}
                      onViewInvoice={onViewInvoice}
                      onDeleteInvoice={onDeleteInvoice}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
});

VirtualizedInvoiceList.displayName = 'VirtualizedInvoiceList';

export default VirtualizedInvoiceList;
