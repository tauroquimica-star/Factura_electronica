
-- Crear tabla para archivos adjuntos de facturas
CREATE TABLE public.invoice_attachments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  invoice_id TEXT NOT NULL,
  file_name TEXT NOT NULL,
  file_size BIGINT NOT NULL,
  file_type TEXT NOT NULL,
  storage_path TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Crear índice para mejorar las consultas por invoice_id
CREATE INDEX idx_invoice_attachments_invoice_id ON public.invoice_attachments(invoice_id);

-- Crear bucket de almacenamiento para archivos de facturas
INSERT INTO storage.buckets (id, name, public) 
VALUES ('invoice-attachments', 'invoice-attachments', false);

-- Políticas de seguridad para el bucket (solo lectura y escritura autenticada)
CREATE POLICY "Allow authenticated users to upload files" ON storage.objects
  FOR INSERT WITH CHECK (bucket_id = 'invoice-attachments');

CREATE POLICY "Allow authenticated users to view files" ON storage.objects
  FOR SELECT USING (bucket_id = 'invoice-attachments');

CREATE POLICY "Allow authenticated users to delete files" ON storage.objects
  FOR DELETE USING (bucket_id = 'invoice-attachments');

-- Agregar trigger para actualizar updated_at en invoices
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Aplicar el trigger a la tabla invoices si no existe
DROP TRIGGER IF EXISTS update_invoices_updated_at ON public.invoices;
CREATE TRIGGER update_invoices_updated_at
    BEFORE UPDATE ON public.invoices
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();
