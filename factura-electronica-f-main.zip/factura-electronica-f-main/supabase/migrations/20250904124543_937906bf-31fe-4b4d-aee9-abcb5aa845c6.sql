-- First, let's see the current policies on the invoices table
SELECT schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check 
FROM pg_policies 
WHERE tablename = 'invoices' 
ORDER BY policyname;

-- Check if there are conflicts in UPDATE policies
-- The issue might be that we have overlapping UPDATE policies that are restrictive

-- Let's drop the conflicting policies and create a single comprehensive UPDATE policy
DROP POLICY IF EXISTS "Contabilidad can update accounting status" ON invoices;
DROP POLICY IF EXISTS "CCR can update CCR status" ON invoices;
DROP POLICY IF EXISTS "Recepción can update invoice status" ON invoices;

-- Create a comprehensive UPDATE policy that allows all authorized roles
CREATE POLICY "Authorized users can update invoices" 
ON invoices FOR UPDATE 
USING (get_current_user_role() = ANY (ARRAY['Contabilidad'::text, 'CCR'::text, 'Admin'::text, 'Recepción'::text]))
WITH CHECK (get_current_user_role() = ANY (ARRAY['Contabilidad'::text, 'CCR'::text, 'Admin'::text, 'Recepción'::text]));