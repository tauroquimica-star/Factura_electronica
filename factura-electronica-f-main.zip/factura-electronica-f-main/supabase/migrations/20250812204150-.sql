-- Enable RLS on existing invoice tables
ALTER TABLE public.invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.invoice_attachments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.invoice_items ENABLE ROW LEVEL SECURITY;

-- Create policies for invoices table
CREATE POLICY "All authenticated users can view invoices" 
ON public.invoices 
FOR SELECT 
TO authenticated
USING (true);

CREATE POLICY "All authenticated users can insert invoices" 
ON public.invoices 
FOR INSERT 
TO authenticated
WITH CHECK (true);

CREATE POLICY "All authenticated users can update invoices" 
ON public.invoices 
FOR UPDATE 
TO authenticated
USING (true);

CREATE POLICY "All authenticated users can delete invoices" 
ON public.invoices 
FOR DELETE 
TO authenticated
USING (true);

-- Create policies for invoice_attachments table
CREATE POLICY "All authenticated users can view invoice_attachments" 
ON public.invoice_attachments 
FOR SELECT 
TO authenticated
USING (true);

CREATE POLICY "All authenticated users can insert invoice_attachments" 
ON public.invoice_attachments 
FOR INSERT 
TO authenticated
WITH CHECK (true);

CREATE POLICY "All authenticated users can update invoice_attachments" 
ON public.invoice_attachments 
FOR UPDATE 
TO authenticated
USING (true);

CREATE POLICY "All authenticated users can delete invoice_attachments" 
ON public.invoice_attachments 
FOR DELETE 
TO authenticated
USING (true);

-- Create policies for invoice_items table
CREATE POLICY "All authenticated users can view invoice_items" 
ON public.invoice_items 
FOR SELECT 
TO authenticated
USING (true);

CREATE POLICY "All authenticated users can insert invoice_items" 
ON public.invoice_items 
FOR INSERT 
TO authenticated
WITH CHECK (true);

CREATE POLICY "All authenticated users can update invoice_items" 
ON public.invoice_items 
FOR UPDATE 
TO authenticated
USING (true);

CREATE POLICY "All authenticated users can delete invoice_items" 
ON public.invoice_items 
FOR DELETE 
TO authenticated
USING (true);

-- Fix search path for update_updated_at_column function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = 'public'
AS $function$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$function$;