-- Crear perfil para el usuario sistemas@tauroquimica.co con rol de Admin
INSERT INTO public.profiles (id, username, role, is_active, created_at, updated_at)
SELECT 
  u.id,
  'sistemas@tauroquimica.co',
  'Admin'::user_role,
  true,
  NOW(),
  NOW()
FROM auth.users u
WHERE u.email = 'sistemas@tauroquimica.co'
  AND NOT EXISTS (
    SELECT 1 FROM public.profiles p 
    WHERE p.id = u.id
  );