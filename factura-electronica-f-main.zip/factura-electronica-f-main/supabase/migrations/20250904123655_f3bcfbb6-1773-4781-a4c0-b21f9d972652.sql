-- Agregar política para permitir a Recepción actualizar estados de custodia y recepción
CREATE POLICY "Recepción can update invoice status" 
ON invoices FOR UPDATE 
USING (get_current_user_role() = ANY (ARRAY['Recepción'::text, 'Admin'::text]))
WITH CHECK (get_current_user_role() = ANY (ARRAY['Recepción'::text, 'Admin'::text]));