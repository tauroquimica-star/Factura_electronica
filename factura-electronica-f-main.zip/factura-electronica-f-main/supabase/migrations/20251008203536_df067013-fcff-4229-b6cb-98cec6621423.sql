-- Add DELETE policy for audit_logs table to allow Admins to delete records
CREATE POLICY "Admins can delete audit logs"
ON public.audit_logs
FOR DELETE
USING (get_current_user_role() = 'Admin');