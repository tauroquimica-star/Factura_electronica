-- Actualizar el rol del usuario sistemas@tauroquimica.co a Admin
UPDATE profiles 
SET role = 'Admin'::user_role, 
    updated_at = NOW()
WHERE id = '94642beb-2148-4fd5-9cd7-abf90f7f91d0';