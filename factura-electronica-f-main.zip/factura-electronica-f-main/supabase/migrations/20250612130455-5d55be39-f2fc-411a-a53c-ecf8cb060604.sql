
-- Create invoices table
CREATE TABLE public.invoices (
  id TEXT PRIMARY KEY,
  invoice_number TEXT NOT NULL,
  provider_name TEXT NOT NULL,
  nit_proveedor TEXT,
  amount DECIMAL(10,2) NOT NULL,
  issue_date DATE NOT NULL,
  reception_date DATE NOT NULL,
  cufe_cude TEXT,
  custodio TEXT,
  observations TEXT,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'sent', 'paid', 'overdue')),
  custodia_contabilidad BOOLEAN DEFAULT FALSE,
  recibido_contabilidad BOOLEAN DEFAULT FALSE,
  recibido_ccr BOOLEAN DEFAULT FALSE,
  fecha_custodia_contabilidad TIMESTAMP WITH TIME ZONE,
  fecha_recibido_contabilidad TIMESTAMP WITH TIME ZONE,
  fecha_recibido_ccr TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create invoice items table
CREATE TABLE public.invoice_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id TEXT REFERENCES public.invoices(id) ON DELETE CASCADE,
  description TEXT NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX idx_invoices_status ON public.invoices(status);
CREATE INDEX idx_invoices_provider ON public.invoices(provider_name);
CREATE INDEX idx_invoice_items_invoice_id ON public.invoice_items(invoice_id);

-- Add trigger to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_invoices_updated_at 
    BEFORE UPDATE ON public.invoices 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
