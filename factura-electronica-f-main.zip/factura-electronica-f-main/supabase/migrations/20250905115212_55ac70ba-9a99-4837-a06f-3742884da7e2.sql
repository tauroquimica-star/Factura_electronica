-- Inspect current policies on invoices after updates
SELECT policyname, cmd, permissive, qual, with_check FROM pg_policies WHERE tablename = 'invoices' ORDER BY policyname;