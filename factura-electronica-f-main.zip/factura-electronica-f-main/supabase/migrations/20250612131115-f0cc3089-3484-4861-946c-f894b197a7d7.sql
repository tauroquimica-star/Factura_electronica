
-- Add quantity column to invoice_items table
ALTER TABLE public.invoice_items 
ADD COLUMN quantity INTEGER NOT NULL DEFAULT 1;

-- Update existing records to have quantity = 1
UPDATE public.invoice_items 
SET quantity = 1 
WHERE quantity IS NULL;
