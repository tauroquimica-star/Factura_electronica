-- Actualizar el perfil del usuario para que su username sea sistemas@tauroquimica.co
UPDATE public.profiles 
SET username = 'sistemas@tauroquimica.co', role = 'Admin'
WHERE id = '94642beb-2148-4fd5-9cd7-abf90f7f91d0';