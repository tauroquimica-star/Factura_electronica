-- Agregar campos para tracking de observaciones
ALTER TABLE invoices 
ADD COLUMN observations_user TEXT,
ADD COLUMN observations_date TIMESTAMP WITH TIME ZONE;