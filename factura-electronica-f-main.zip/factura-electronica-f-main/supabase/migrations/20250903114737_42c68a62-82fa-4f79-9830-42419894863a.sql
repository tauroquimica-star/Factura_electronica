-- Fix infinite recursion in profiles policies by using get_current_user_role function
-- Drop the problematic policies that cause recursion
DROP POLICY IF EXISTS "Admins can view all profiles" ON public.profiles;
DROP POLICY IF EXISTS "Admins can update any profile" ON public.profiles;  
DROP POLICY IF EXISTS "Admins can delete profiles" ON public.profiles;

-- Create new policies using the get_current_user_role function instead of self-referencing profiles table
CREATE POLICY "Admins can view all profiles"
ON public.profiles
FOR SELECT
USING (get_current_user_role() = 'Admin');

CREATE POLICY "Admins can update any profile"
ON public.profiles
FOR UPDATE
USING (get_current_user_role() = 'Admin');

CREATE POLICY "Admins can delete profiles"
ON public.profiles
FOR DELETE
USING ((get_current_user_role() = 'Admin') AND (id != auth.uid()));