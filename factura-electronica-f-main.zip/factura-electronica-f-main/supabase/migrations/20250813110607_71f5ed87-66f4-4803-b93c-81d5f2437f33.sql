-- Temporarily disable RLS on invoice tables to allow access with local authentication
-- This is needed because the current RLS policies require Supabase Auth, but the app uses local auth

ALTER TABLE invoices DISABLE ROW LEVEL SECURITY;
ALTER TABLE invoice_items DISABLE ROW LEVEL SECURITY;  
ALTER TABLE invoice_attachments DISABLE ROW LEVEL SECURITY;