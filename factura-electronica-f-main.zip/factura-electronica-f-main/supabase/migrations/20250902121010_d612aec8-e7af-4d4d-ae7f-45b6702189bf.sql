-- Actualizar el usuario sistemas@tauroquimica.co para que tenga rol de Admin
UPDATE public.profiles 
SET role = 'Admin', is_active = true 
WHERE username = 'sistemas@tauroquimica.co';

-- Si el usuario no existe aún, verificamos si existe en auth.users y lo insertamos
INSERT INTO public.profiles (id, username, role, is_active, created_at, updated_at)
SELECT 
  u.id,
  'sistemas@tauroquimica.co',
  'Admin'::user_role,
  true,
  NOW(),
  NOW()
FROM auth.users u
WHERE u.email = 'sistemas@tauroquimica.co'
  AND NOT EXISTS (
    SELECT 1 FROM public.profiles p 
    WHERE p.id = u.id
  );