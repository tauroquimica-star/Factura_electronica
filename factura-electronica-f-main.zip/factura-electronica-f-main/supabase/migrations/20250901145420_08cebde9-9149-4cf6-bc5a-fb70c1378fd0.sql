-- Habilitar RLS en las tablas de storage para corregir errores de seguridad
-- Estas son las tablas que mostraron errores en el linter

-- No podemos habilitar RLS en tablas de storage ya que son gestionadas por Supabase
-- Las políticas de storage ya están definidas, solo verificamos que están activas

-- Verificar que las políticas existentes están funcionando
SELECT schemaname, tablename, rowsecurity 
FROM pg_tables 
WHERE schemaname IN ('public', 'storage') 
AND tablename IN ('buckets', 'objects');