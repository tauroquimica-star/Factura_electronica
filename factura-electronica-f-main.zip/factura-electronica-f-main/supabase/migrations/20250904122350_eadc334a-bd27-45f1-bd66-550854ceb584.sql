-- Agregar 'Recepción' al enum user_role
ALTER TYPE user_role ADD VALUE 'Recepción';

-- Actualizar políticas RLS para incluir rol Recepción

-- Permitir a Recepción insertar facturas
DROP POLICY IF EXISTS "Authorized users can insert invoices" ON invoices;
CREATE POLICY "Authorized users can insert invoices" 
ON invoices FOR INSERT 
WITH CHECK (get_current_user_role() = ANY (ARRAY['Contabilidad'::text, 'CCR'::text, 'Admin'::text, 'Recepción'::text]));

-- Permitir a Recepción ver todas las facturas
DROP POLICY IF EXISTS "Recepción can view all invoices" ON invoices;
CREATE POLICY "Recepción can view all invoices" 
ON invoices FOR SELECT 
USING (get_current_user_role() = ANY (ARRAY['Recepción'::text, 'Admin'::text]));

-- Permitir a Recepción manejar attachments de facturas
DROP POLICY IF EXISTS "Authorized users can manage attachments" ON invoice_attachments;
CREATE POLICY "Authorized users can manage attachments" 
ON invoice_attachments FOR ALL 
USING ((get_current_user_role() = ANY (ARRAY['Contabilidad'::text, 'CCR'::text, 'Admin'::text, 'Recepción'::text])) AND (EXISTS ( SELECT 1 FROM invoices WHERE (invoices.id = invoice_attachments.invoice_id))))
WITH CHECK (get_current_user_role() = ANY (ARRAY['Contabilidad'::text, 'CCR'::text, 'Admin'::text, 'Recepción'::text]));

-- Permitir a Recepción manejar items de facturas
DROP POLICY IF EXISTS "Authorized users can manage invoice items" ON invoice_items;
CREATE POLICY "Authorized users can manage invoice items" 
ON invoice_items FOR ALL 
USING ((get_current_user_role() = ANY (ARRAY['Contabilidad'::text, 'CCR'::text, 'Admin'::text, 'Recepción'::text])) AND (EXISTS ( SELECT 1 FROM invoices WHERE (invoices.id = invoice_items.invoice_id))))
WITH CHECK (get_current_user_role() = ANY (ARRAY['Contabilidad'::text, 'CCR'::text, 'Admin'::text, 'Recepción'::text]));