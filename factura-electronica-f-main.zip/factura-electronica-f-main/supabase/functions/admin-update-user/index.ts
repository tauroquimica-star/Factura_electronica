import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

type Body = {
  user_id: string;
  email?: string;
  password?: string;
  username?: string;
  role?: 'Admin' | 'Contabilidad' | 'CCR' | 'user';
  is_active?: boolean;
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const body = (await req.json()) as Body;
    if (!body?.user_id) {
      return new Response(JSON.stringify({ error: 'user_id es requerido' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      { auth: { autoRefreshToken: false, persistSession: false } }
    );

    const supabaseAuthed = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: req.headers.get('Authorization') || '' } } }
    );

    const { data: authUser, error: authErr } = await supabaseAuthed.auth.getUser();
    if (authErr || !authUser?.user) {
      return new Response(JSON.stringify({ error: 'No autenticado' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { data: role, error: roleErr } = await supabaseAuthed.rpc('get_current_user_role');
    if (roleErr || role !== 'Admin') {
      return new Response(JSON.stringify({ error: 'No autorizado' }), {
        status: 403,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Update auth user (email/password)
    if (body.email || body.password) {
      const { error: updErr } = await supabaseAdmin.auth.admin.updateUserById(body.user_id, {
        email: body.email,
        password: body.password,
        user_metadata: {
          ...(body.username ? { username: body.username } : {}),
          ...(body.role ? { role: body.role } : {}),
        },
      });
      if (updErr) {
        return new Response(JSON.stringify({ error: updErr.message }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
    } else if (body.username || body.role) {
      // still update metadata only if provided and no email/password
      const { error: metaErr } = await supabaseAdmin.auth.admin.updateUserById(body.user_id, {
        user_metadata: {
          ...(body.username ? { username: body.username } : {}),
          ...(body.role ? { role: body.role } : {}),
        },
      });
      if (metaErr) {
        return new Response(JSON.stringify({ error: metaErr.message }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
    }

    // Update public profile
    const profileUpdate: Record<string, unknown> = {};
    if (typeof body.username === 'string') profileUpdate.username = body.username;
    if (typeof body.role === 'string') profileUpdate.role = body.role;
    if (typeof body.is_active === 'boolean') profileUpdate.is_active = body.is_active;

    if (Object.keys(profileUpdate).length > 0) {
      const { error: profileErr } = await supabaseAdmin
        .from('profiles')
        .update(profileUpdate)
        .eq('id', body.user_id);

      if (profileErr) {
        return new Response(JSON.stringify({ error: profileErr.message }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
    }

    return new Response(JSON.stringify({ success: true }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (e) {
    const errorMessage = e instanceof Error ? e.message : 'Error desconocido';
    console.error('admin-update-user error:', errorMessage, e);
    return new Response(JSON.stringify({ error: `Error interno: ${errorMessage}` }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});